    <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
<head>
<title></title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
 <br/>
<style type="text/css">
 	p {margin: 0; padding: 0;}	.ft10{font-size:22px;font-family:Times;color:#ff0000;}
	.ft11{font-size:19px;font-family:Times;color:#000000;}
	.ft12{font-size:19px;font-family:Times;color:#0000ff;}
	.ft13{font-size:15px;font-family:Times;color:#000000;}
	.ft14{font-size:15px;font-family:Times;color:#000000;}
	.ft15{font-size:15px;font-family:Times;color:#0000ff;}
	.ft16{font-size:15px;line-height:32px;font-family:Times;color:#000000;}


 
 </style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
    <!-- Include html2canvas library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
 


</head>
 


<button class="btnclr btn btn-default dropdown-toggle  boxes filip-horizontal mobile_para"  onclick="downloadPagesAsPDF()" style="margin-left:250px;" ><span  class="fa fa-download"></span>Download </button>

<body bgcolor="#A0A0A0" vlink="blue" link="blue"   >

<div id="download"  >

<div id="page1-div" style="position:relative;width:918px;height:1188px;margin-left: 450px;">
<img width="918" height="1188" src="<?php echo base_url('assets/payrollform/fw3/target001.png'); ?>" alt="background image" style="border: 1px solid black;"   />
<p style="position:absolute;top:135px;left:402px;white-space:nowrap" class="ft10"><b>Attention:&#160;</b></p>
<p style="position:absolute;top:175px;left:108px;white-space:nowrap;font-size: 23px;" class="ft11">You may file Forms W-2 and W-3 electronically on the SSA’s&#160;</p>
<p style="position:absolute;top:175px;left:679px;white-space:nowrap;font-size: 23px;" class="ft12"><a href="http://www.socialsecurity.gov/employer"><span style="color:blue;">  Employer </span>  &#160;</a></p>
<p style="position:absolute;top:201px;left:108px;white-space:nowrap ;font-size: 23px;" class="ft12"><a href="http://www.socialsecurity.gov/employer"><span style="color: blue;">W-2 Filing Instructions and Information</a></p>
<p style="position:absolute;top:203px;left:477px;white-space:nowrap;font-size: 23px;" class="ft11">&#160;web page, which is also accessible&#160;</p>
<p style="position:absolute;top:228px;left:108px;white-space:nowrap;font-size: 23px;" class="ft11"><span style="color: blue;"><a href="http://www.socialsecurity.gov/employer"><span style="color: black;">at&#160;</a></p>


<p style="position:absolute;top:226px;left:133px;white-space:nowrap;font-size:23px;margin-left:-3px;" class="ft12"><a href="http://www.socialsecurity.gov/employer"> <span style="color: blue;">www.socialsecurity.gov/employer</a></p>



<p style="position:absolute;top:228px;left:441px;white-space:nowrap;font-size: 23px;" class="ft11"><span style="color:blue;"><a href="http://www.socialsecurity.gov/employer"></a>. &#160;<span style="color:black;">You can create fill-in versions of&#160;</p>



<p style="position:absolute;top:253px;left:108px;white-space:nowrap;font-size: 23px;" class="ft11">Forms W-2 and W-3 for filing with SSA. You may also print out copies for&#160;</p>
<p style="position:absolute;top:279px;left:108px;white-space:nowrap;font-size: 23px;" class="ft11">filing with state or local governments, distribution to your employees, and&#160;</p>
<p style="position:absolute;top:304px;left:108px;white-space:nowrap;font-size: 23px;" class="ft11">for your records.</p>


    

<p style="position:absolute;top:341px;left:108px;white-space:nowrap ;font-size: 19px;" class="ft13"><b>Note:</b>&#160;Copy A of this form is provided for informational purposes only. Copy A appears in&#160;</p>
<p style="position:absolute;top:361px;left:108px;white-space:nowrap ;font-size: 19px;" class="ft14">red, similar to the official IRS form. The official printed version of this IRS form is scannable,&#160;</p>
<p style="position:absolute;top:382px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14">but the online version of it, printed from this website, is not. Do&#160;</p>
<p style="position:absolute;top:382px;left:596px;white-space:nowrap;font-size: 19px;" class="ft13"><b>not</b>&#160;print and file Copy A&#160;</p>
<p style="position:absolute;top:403px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14">downloaded from this website with the SSA; a&#160;</p>
<p style="position:absolute;top:403px;left:467px;white-space:nowrap;font-size: 19px;" class="ft13"><b>penalty</b>&#160;may be imposed for filing forms that&#160;</p>
<p style="position:absolute;top:425px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14">can’t be scanned. See the penalties section in the current&#160;</p>
<p style="position:absolute;top:423px;left:551px;white-space:nowrap ;font-size: 19px;" class="ft15"><a href="https://www.irs.gov/instructions/iw2w3/index-div"><span style="color:blue;">General Instructions for Forms&#160;</a></p>
<p style="position:absolute;top:445px;left:108px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="https://www.irs.gov/instructions/iw2w3/index-div"><span style="color:blue;">W-2 and W-3</a></p>
<p style="position:absolute;top:444px;left:210px;white-space:nowrap;font-size: 19px;" class="ft14"><a href="https://www.irs.gov/instructions/iw2w3/index-div"><span style="color:black;">, available at&#160;</a></p>
<p style="position:absolute;top:442px;left:311px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="http://www.irs.gov/w2"><span style="color:blue;">www.irs.gov/w2</a></p>
<p style="position:absolute;top:445px;left:440px;white-space:nowrap;font-size: 19px;" class="ft14">, for more information.</p>
<p style="position:absolute;top:477px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14">Please note that Copy B and other copies of this form, which appear in black, may be&#160;</p>
<p style="position:absolute;top:498px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14">downloaded, filled in, and printed and used to satisfy the requirement to provide the&#160;</p>
<p style="position:absolute;top:519px;left:108px;white-space:nowrap;font-size: 19px;" class="ft16">information to the recipient.<br/>To order official IRS information returns such as Forms W-2 and W-3, which include a&#160;</p>
<p style="position:absolute;top:572px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14"><a href="https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns"><span style="color:black;">scannable Copy A for filing, go to IRS’&#160;</a></p>
<p style="position:absolute;top:570px;left:407px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns"><span style="color:blue;">Online Ordering for Information Returns and&#160;</a></p>
<p style="position:absolute;top:591px;left:108px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns"><span style="color:blue;">Employer Returns</a></p>
<p style="position:absolute;top:591px;left:246px;white-space:nowrap;font-size: 19px;" class="ft14"><a href="http://www.irs.gov/orderforms">&#160;<span style="color:black;">page, or visit&#160;</a></p>
<p style="position:absolute;top:591px;left:353px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="http://www.irs.gov/orderforms"><span style="color:blue;">www.irs.gov/orderforms</a></p>
<p style="position:absolute;top:593px;left:538px;white-space:nowrap;font-size: 19px;" class="ft14"><a href="http://www.irs.gov/orderforms">&#160;<span style="color:black;">and click on Employer and&#160;</a></p>
<p style="position:absolute;top:613px;left:108px;white-space:nowrap;font-size: 19px;" class="ft16">Information returns. We’ll mail you the scannable forms and any other products you order.<br/>See IRS Publications&#160;</p>
<p style="position:absolute;top:645px;left:275px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="http://www.irs.gov/pub1141"><span style="color:blue;">1141</a></p>
<p style="position:absolute;top:645px;left:313px;white-space:nowrap;font-size: 19px;" class="ft14">,&#160;</p>
<p style="position:absolute;top:645px;left:323px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="http://www.irs.gov/pub1167"><span style="color:blue;">1167</a></p>
<p style="position:absolute;top:645px;left:361px;white-space:nowrap;font-size: 19px;" class="ft14"><a href="http://www.irs.gov/pub1179"><span style="color:black;">, and&#160;</a></p>
<p style="position:absolute;top:645px;left:404px;white-space:nowrap;font-size: 19px;" class="ft15"><a href="http://www.irs.gov/pub1179"><span style="color:blue;">1179</a></p>
<p style="position:absolute;top:645px;left:443px;white-space:nowrap;font-size: 19px;" class="ft14"><a href="http://www.irs.gov/pub1179">&#160;<span style="color:black;">for more information about printing these tax&#160;</a></p>
<p style="position:absolute;top:666px;left:108px;white-space:nowrap;font-size: 19px;" class="ft14">forms.</p>
</div>
</body>
</html>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
<head>
<title></title>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
 <br/>
<style type="text/css">
 	p {margin: 0; padding: 0;}	.ft20{font-size:13px;font-family:Times;color:#000000;}
	.ft21{font-size:13px;font-family:Times;color:#ff0000;}
	.ft22{font-size:8px;font-family:Times;color:#ff0000;}
	.ft23{font-size:8px;font-family:Times;color:#ff0000;}
	.ft24{font-size:10px;font-family:Times;color:#ff0000;}
	.ft25{font-size:25px;font-family:Times;color:#000000;}
	.ft26{font-size:17px;font-family:Times;color:#ff0000;}
	.ft27{font-size:25px;font-family:Times;color:#000000;}
	.ft28{font-size:7px;font-family:Times;color:#ff0000;}
	.ft29{font-size:10px;font-family:Times;color:#000000;}
	.ft210{font-size:10px;font-family:Times;color:#000000;}
	.ft211{font-size:16px;font-family:Times;color:#000000;}
	.ft212{font-size:10px;font-family:Times;color:#000000;}
	.ft213{font-size:12px;font-family:Times;color:#000000;}
	.ft214{font-size:8px;font-family:Times;color:#000000;}
	.ft215{font-size:8px;line-height:17px;font-family:Times;color:#ff0000;}
	.ft216{font-size:8px;line-height:18px;font-family:Times;color:#ff0000;}
	.ft217{font-size:8px;line-height:12px;font-family:Times;color:#ff0000;}
	.ft218{font-size:10px;line-height:15px;font-family:Times;color:#000000;}
	.ft219{font-size:10px;line-height:17px;font-family:Times;color:#000000;}
 </style>
</head>



<body bgcolor="#A0A0A0" vlink="blue" link="blue">
 <div id="page2-div" style="position:relative;width:918px;height:1188px;margin-left: 450px;border: 1px solid black;">
<img width="918" height="1188" src="<?php echo base_url('assets/payrollform/fw3/target002.png'); ?>" alt="background image"/>
<p style="position:absolute;top:38px;left:54px;white-space:nowrap" class="ft20">&#160;&#160;</p>
<p style="position:absolute;top:34px;left:404px;white-space:nowrap" class="ft21"><b>DO NOT STAPLE</b></p>
<p style="position:absolute;top:64px;left:73px;white-space:nowrap" class="ft20">33333</p>
<p style="position:absolute;top:55px;left:154px;white-space:nowrap" class="ft22"><b>a &#160;&#160;</b>Control number</p>
<p style="position:absolute;top:56px;left:332px;white-space:nowrap" class="ft215"><b>For Official Use Only: &#160;<br/>OMB No. 1545-0008</b></p>
<p style="position:absolute;top:92px;left:62px;white-space:nowrap" class="ft22"><b>b &#160;</b></p>
<p style="position:absolute;top:108px;left:72px;white-space:nowrap" class="ft24"><b>Kind of Payer&#160;</b></p>
<p style="position:absolute;top:125px;left:72px;white-space:nowrap" class="ft23">(Check one)</p>
<p style="position:absolute;top:92px;left:182px;white-space:nowrap" class="ft23">941</p>
<p style="position:absolute;top:92px;left:230px;white-space:nowrap" class="ft23">Military</p>
<p style="position:absolute;top:92px;left:290px;white-space:nowrap" class="ft23">943</p>
<p style="position:absolute;top:92px;left:344px;white-space:nowrap" class="ft23">944</p>
<p style="position:absolute;top:131px;left:179px;white-space:nowrap" class="ft23">CT-1</p>
<p style="position:absolute;top:122px;left:232px;white-space:nowrap" class="ft23">Hshld.&#160;</p>
<p style="position:absolute;top:131px;left:232px;white-space:nowrap" class="ft23">emp.</p>
<p style="position:absolute;top:122px;left:281px;white-space:nowrap" class="ft23">Medicare&#160;</p>
<p style="position:absolute;top:131px;left:277px;white-space:nowrap" class="ft23">govt. emp.</p>
<p style="position:absolute;top:92px;left:409px;white-space:nowrap" class="ft22"><b>&#160;</b></p>
<p style="position:absolute;top:108px;left:409px;white-space:nowrap" class="ft24"><b>Kind of Employer&#160;</b></p>
<p style="position:absolute;top:125px;left:409px;white-space:nowrap" class="ft23">(Check one)</p>
<p style="position:absolute;top:92px;left:533px;white-space:nowrap" class="ft23">None apply</p>
<p style="position:absolute;top:92px;left:602px;white-space:nowrap" class="ft23">501c non-govt.</p>
<p style="position:absolute;top:122px;left:535px;white-space:nowrap" class="ft23">State/local&#160;</p>
<p style="position:absolute;top:131px;left:538px;white-space:nowrap" class="ft23">non-501c</p>
<p style="position:absolute;top:131px;left:599px;white-space:nowrap" class="ft23">State/local 501c&#160;Federal govt.</p>
<p style="position:absolute;top:94px;left:791px;white-space:nowrap" class="ft23">Third-party&#160;</p>
<p style="position:absolute;top:103px;left:798px;white-space:nowrap" class="ft23">sick pay &#160; &#160;&#160;</p>
<p style="position:absolute;top:120px;left:796px;white-space:nowrap" class="ft23">(Check if&#160;</p>
<p style="position:absolute;top:129px;left:792px;white-space:nowrap" class="ft23">applicable)&#160;</p>







<?php
$employee_count = isset($get_total_customersData[0]['employee_count']) ? $get_total_customersData[0]['employee_count'] : '';
?>



<p style="position:absolute;top:163px;left:62px;white-space:nowrap" class="ft22"><b>c</b>&#160;Total number of Forms W-2 <br> <span style="color: black;font-size: large;"><?php echo htmlspecialchars($employee_count, ENT_QUOTES, 'UTF-8');  ?></p>






 

<p style="position:absolute;top:163px;left:234px;white-space:nowrap" class="ft22"><b>d</b>&#160;Establishment number</p>


<?php
$Federal_Pin_Number = isset($get_cominfo[0]['Federal_Pin_Number']) ? $get_cominfo[0]['Federal_Pin_Number'] : '';
?>

<p style="position:absolute;top:199px;left:62px;white-space:nowrap" class="ft22">
    <b>e</b>&#160;Employer identification number (EIN) <br>
   <span style="color: black;font-size: large;"> <?php echo htmlspecialchars($Federal_Pin_Number, ENT_QUOTES, 'UTF-8'); ?> </span>
</p>




<?php
$company_name = isset($get_cominfo[0]['company_name']) ? $get_cominfo[0]['company_name'] : '';
?>
<p style="position:absolute;top:235px;left:62px;white-space:nowrap" class="ft22"><b>f</b>&#160; Employer’s name <br> <span style="color: black;font-size: large;"><?php echo htmlspecialchars($company_name, ENT_QUOTES, 'UTF-8'); ?></p>
<?php
$address = isset($get_cominfo[0]['address']) ? $get_cominfo[0]['address'] : 'Default Address';
 ?>
 
 
 
 
 
 
 
<p style="position:absolute;top:361px;left:62px;white-space:nowrap" class="ft216"><span> 
     <span style="color: black;font-size: large;position: absolute; bottom: 96px;">
       <?php echo htmlspecialchars($address, ENT_QUOTES, 'UTF-8'); ?></span> 
    
    
 





     
    
    <b>g</b>&#160; Employer’s address and ZIP code<br/>                   
    
    
    
    
    
    
    <b>h</b>&#160;Other EIN used this year</p>
 
 
 
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 <?php
 
 
 
 
$overalltotal_amount = isset($get_payslip_info[0]['overalltotal_amount']) ? round($get_payslip_info[0]['overalltotal_amount'], 2) : '0';
 ?>
<p style="position:absolute;top:163px;left:415px;white-space:nowrap" class="ft22"><b>1&#160;</b>                  Wages, tips, other compensation <br> <span style="color: black;font-size: large;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?> </p>
<?php
$ftotal_amount = isset($get_payslip_info[0]['ftotal_amount']) ? $get_payslip_info[0]['ftotal_amount'] : '0';
 ?>
<p style="position:absolute;top:163px;left:647px;white-space:nowrap" class="ft22"><b>2&#160;</b>Federal income tax withheld    <br> <span style="color: black;font-size: large;"> $<?php echo htmlspecialchars($ftotal_amount, ENT_QUOTES, 'UTF-8'); ?>          </p>
<p style="position:absolute;top:199px;left:415px;white-space:nowrap" class="ft22"><b>3&#160;</b>Social security wages  <br> <span style="color: black;font-size: large;"> $<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>   </p>


<?php
$stotal_amount = isset($get_payslip_info[0]['stotal_amount']) ? round($get_payslip_info[0]['stotal_amount'], 2) : '0';
 ?>
 
 
 
 
<p style="position:absolute;top:199px;left:647px;white-space:nowrap" class="ft22"><b>4&#160;</b>Social security tax withheld <br>  <span style="color: black;font-size: large;">$<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>   </p>
<p style="position:absolute;top:235px;left:415px;white-space:nowrap" class="ft22"><b>5&#160;</b>Medicare wages and tips   <br>  <span style="color: black;font-size: large;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>     </p>
 
 
 
<?php
$mtotal_amount = isset($get_payslip_info[0]['mtotal_amount']) ? round($get_payslip_info[0]['mtotal_amount'], 2) : '0';
?>

 
<p style="position:absolute;top:235px;left:647px;white-space:nowrap" class="ft22"><b>6&#160;</b>Medicare tax withheld <br>  <span style="color: black;font-size: large;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?> </p>
<p style="position:absolute;top:271px;left:415px;white-space:nowrap" class="ft22"><b>7&#160;</b>Social security tips</p>
<p style="position:absolute;top:271px;left:647px;white-space:nowrap" class="ft22"><b>8&#160;</b>Allocated tips</p>
<p style="position:absolute;top:308px;left:415px;white-space:nowrap" class="ft22"><b>9</b></p>
<p style="position:absolute;top:307px;left:639px;white-space:nowrap" class="ft22"><b>10&#160;</b>Dependent care benefits</p>
<p style="position:absolute;top:343px;left:407px;white-space:nowrap" class="ft22"><b>11&#160;</b>Nonqualified plans</p>
<p style="position:absolute;top:343px;left:639px;white-space:nowrap" class="ft22"><b>12a&#160;</b>Deferred compensation</p>
<p style="position:absolute;top:380px;left:639px;white-space:nowrap" class="ft22"><b>12b</b></p>
<p style="position:absolute;top:379px;left:407px;white-space:nowrap" class="ft22"><b>13&#160;</b>For third-party sick pay use only</p>
<p style="position:absolute;top:415px;left:407px;white-space:nowrap" class="ft22"><b>14&#160;</b>Income tax withheld by payer of third-party sick pay</p>
<p style="position:absolute;top:415px;left:59px;white-space:nowrap" class="ft22"><b>15&#160;</b>State<b>&#160;</b>&#160; <br> <span style="color: black;font-size: large;">  <?php echo htmlspecialchars('NJ', ENT_QUOTES, 'UTF-8'); ?>  </p>


<?php
$State_Tax_ID_Number = isset($get_cominfo[0]['State_Tax_ID_Number']) ? $get_cominfo[0]['State_Tax_ID_Number'] : '';
?>

<p style="position:absolute;top:415px;left:125px;white-space:nowrap" class="ft23">Employer’s state ID number <br> <span style="color: black;font-size: large;">  <?php echo htmlspecialchars($State_Tax_ID_Number, ENT_QUOTES, 'UTF-8'); ?>  </p>
 
 
 

<?php
$overalltotal_statetax = isset($total_state_tax[0]['overalltotal_statetax']) ? round($total_state_tax[0]['overalltotal_statetax'], 2) : '0';
?>




<p style="position:absolute;top:451px;left:59px;white-space:nowrap" class="ft22"><b>16</b>&#160;State wages, tips, etc. <br> <span style="color: black;font-size: large;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?></span></p>

<p style="position:absolute;top:451px;left:231px;white-space:nowrap" class="ft22"><b>17</b>&#160;State income tax <br> <span style="color: black;font-size: large;">$<?php echo htmlspecialchars(round($total_state_tax, 2), ENT_QUOTES, 'UTF-8'); ?>



<?php
$overalltotal_localtax = isset($total_local_tax[0]['overalltotal_localtax']) ? round($total_local_tax[0]['overalltotal_localtax'], 2) : '0';
?>




<p style="position:absolute;top:451px;left:407px;white-space:nowrap" class="ft22">
    <b>18&#160;</b>Local wages, tips, etc. <br> 
    <span style="color: black;font-size: large;"> 
        $<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>  
    </span>
</p>



<p style="position:absolute;top:451px;left:639px;white-space:nowrap" class="ft22"><b>19&#160;</b>Local income tax <br> 
    <span style="color: black;font-size: large;"> 
        $<?php echo htmlspecialchars($overalltotal_localtax, ENT_QUOTES, 'UTF-8'); ?>  
    </span></p>





<?php
$mobile = isset($get_cominfo[0]['mobile']) ? $get_cominfo[0]['mobile'] : '';
 ?>
 <?php
$username = isset($get_employer_federaltax[0]['username']) ? $get_employer_federaltax[0]['username'] : '';
 ?>
<p style="position:absolute;top:487px;left:72px;white-space:nowrap" class="ft23">Employer’s contact person  <br> <span style="color: black;font-size: large;"> <?php echo htmlspecialchars('Tam Doan', ENT_QUOTES, 'UTF-8'); ?></p>
<p style="position:absolute;top:487px;left:422px;white-space:nowrap" class="ft23">Employer’s telephone number <br>  <span style="color: black;font-size: large;"><?php echo htmlspecialchars($mobile, ENT_QUOTES, 'UTF-8'); ?> </p>
<p style="position:absolute;top:488px;left:654px;white-space:nowrap" class="ft23">For Official Use Only</p>
<p style="position:absolute;top:523px;left:72px;white-space:nowrap" class="ft23">Employer’s fax number</p>
<?php
$email = isset($employeer[0]['email']) ? $employeer[0]['email'] : ''; 
 ?>
<p style="position:absolute;top:523px;left:422px;white-space:nowrap" class="ft23">Employer’s email address  <br> <span style="color: black;font-size: large;"> <?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>  </p>
<p style="position:absolute;top:563px;left:54px;white-space:nowrap" class="ft217">Under&#160;penalties&#160;of&#160;perjury,&#160;I&#160;declare&#160;that&#160;I&#160;have&#160;examined&#160;this&#160;return&#160;and&#160;accompanying&#160;documents,&#160;and,&#160;to&#160;the&#160;best&#160;of&#160;my&#160;knowledge&#160;and&#160;belief,&#160;they&#160;are&#160;true,&#160;correct,&#160;and&#160;<br/>complete.</p>
<p style="position:absolute;top:597px;left:54px;white-space:nowrap" class="ft23">Signature:</p>
<p style="position:absolute;top:598px;left:410px;white-space:nowrap" class="ft23">Title:</p>
<p style="position:absolute;top:597px;left:702px;white-space:nowrap" class="ft23">Date:</p>
<p style="position:absolute;top:632px;left:54px;white-space:nowrap" class="ft23">Form</p>
<p style="position:absolute;top:615px;left:86px;white-space:nowrap" class="ft25"><b>W-3</b></p>
<p style="position:absolute;top:623px;left:151px;white-space:nowrap" class="ft26"><b>Transmittal of Wage and Tax Statements</b></p>
<p style="position:absolute;top:620px;left:572px;white-space:nowrap" class="ft27"><?php echo date('Y'); ?></p>
<p style="position:absolute;top:622px;left:754px;white-space:nowrap" class="ft28">Department of the Treasury&#160;</p>
<p style="position:absolute;top:632px;left:764px;white-space:nowrap" class="ft28">Internal Revenue Service</p>
<p style="position:absolute;top:650px;left:54px;white-space:nowrap" class="ft218"><b>Send this entire page with the entire Copy A page of Form(s) W-2 to the Social Security Administration (SSA). &#160;<br/>Photocopies are not acceptable. Do not send Form W-3 if you filed electronically with the SSA.&#160;<br/>Do not&#160;</b>send any payment (cash, checks, money orders, etc.) with Forms W-2 and W-3.</p>
<p style="position:absolute;top:700px;left:54px;white-space:nowrap" class="ft211"><b>Reminder</b></p>
<p style="position:absolute;top:726px;left:54px;white-space:nowrap" class="ft29"><b>Separate instructions.&#160;</b>See the 2024 General Instructions for Forms&#160;</p>
<p style="position:absolute;top:739px;left:54px;white-space:nowrap" class="ft210">W-2</p>
<p style="position:absolute;top:739px;left:76px;white-space:nowrap" class="ft29"><b>&#160;</b>and W-3 for information on completing this form. Do not file Form&#160;</p>
<p style="position:absolute;top:752px;left:54px;white-space:nowrap" class="ft210">W-3 for Form(s) W-2 that were submitted electronically to the SSA.</p>
<p style="position:absolute;top:770px;left:54px;white-space:nowrap" class="ft211"><b>Purpose of Form</b></p>
<p style="position:absolute;top:796px;left:54px;white-space:nowrap" class="ft210">Complete a Form W-3 transmittal only when filing paper Copy A of&#160;</p>
<p style="position:absolute;top:809px;left:54px;white-space:nowrap" class="ft210">Form(s) W-2, Wage and Tax Statement. Don’t file Form W-3 alone. All&#160;</p>
<p style="position:absolute;top:821px;left:54px;white-space:nowrap" class="ft210">paper forms&#160;</p>
<p style="position:absolute;top:821px;left:122px;white-space:nowrap" class="ft29"><b>must&#160;</b>comply with IRS standards and be machine readable.&#160;</p>
<p style="position:absolute;top:834px;left:54px;white-space:nowrap" class="ft210">Photocopies are&#160;</p>
<p style="position:absolute;top:834px;left:145px;white-space:nowrap" class="ft29"><b>not</b>&#160;acceptable. Use a Form W-3 even if only one&#160;</p>
<p style="position:absolute;top:847px;left:54px;white-space:nowrap" class="ft210">paper Form W-2 is being filed. Make sure both the Form W-3 and&#160;</p>
<p style="position:absolute;top:860px;left:54px;white-space:nowrap" class="ft210">Form(s) W-2 show the correct tax year and employer identification&#160;</p>
<p style="position:absolute;top:872px;left:54px;white-space:nowrap" class="ft210">number (EIN). Make a copy of this form and keep it with Copy D (For&#160;</p>
<p style="position:absolute;top:885px;left:54px;white-space:nowrap" class="ft210">Employer) of Form(s) W-2 for your records. The IRS recommends&#160;</p>
<p style="position:absolute;top:898px;left:54px;white-space:nowrap" class="ft210">retaining copies of these forms for 4 years.</p>
<p style="position:absolute;top:916px;left:54px;white-space:nowrap" class="ft211"><b>E-Filing</b></p>
<p style="position:absolute;top:942px;left:54px;white-space:nowrap" class="ft210">The SSA strongly suggests employers report Form W-3 and Forms W-2&#160;</p>
<p style="position:absolute;top:955px;left:54px;white-space:nowrap" class="ft210">Copy A electronically instead of on paper. The SSA provides two free &#160;&#160;</p>
<p style="position:absolute;top:968px;left:54px;white-space:nowrap" class="ft219">e-filing options on its Business Services Online (BSO) website.<br/>•&#160;</p>
<p style="position:absolute;top:985px;left:63px;white-space:nowrap" class="ft29"><b>W-2 Online.&#160;</b>Use fill-in forms to create, save, print, and submit up<b>&#160;</b>to&#160;</p>
<p style="position:absolute;top:998px;left:54px;white-space:nowrap" class="ft219">50 Forms W-2 at a time to the SSA.<br/>•&#160;</p>
<p style="position:absolute;top:1015px;left:63px;white-space:nowrap" class="ft29"><b>File Upload.&#160;</b>Upload wage files to the SSA you have created<b>&#160;</b>using&#160;</p>
<p style="position:absolute;top:1028px;left:54px;white-space:nowrap" class="ft210">payroll or tax software that formats the files according to</p>
<p style="position:absolute;top:1027px;left:357px;white-space:nowrap" class="ft29"><b>&#160;</b>the<b>&#160;</b>SSA’s&#160;</p>
<p style="position:absolute;top:1040px;left:54px;white-space:nowrap" class="ft212"><i>Specifications for Filing Forms W-2 Electronically (EFW2)</i>.</p>
<p style="position:absolute;top:1058px;left:66px;white-space:nowrap" class="ft210">W-2 Online fill-in forms or file uploads will be on time if submitted by&#160;</p>
<p style="position:absolute;top:1070px;left:54px;white-space:nowrap" class="ft29"><b>January 31, 2025</b>. For more information, go to&#160;<i>www.SSA.gov/bso</i>.<i>&#160;</i>First-</p>
<p style="position:absolute;top:1083px;left:54px;white-space:nowrap" class="ft210">time filers, select “<i>Register</i>”; returning filers, select “<i>Log In</i>.”</p>
<p style="position:absolute;top:893px;left:475px;white-space:nowrap" class="ft211"><b>When To File Paper Forms</b></p>
<p style="position:absolute;top:919px;left:475px;white-space:nowrap" class="ft210">Mail Form W-3 with Copy A of Form(s) W-2 by&#160;</p>
<p style="position:absolute;top:919px;left:726px;white-space:nowrap" class="ft29"><b>January 31, 2025</b>.</p>
<p style="position:absolute;top:938px;left:475px;white-space:nowrap" class="ft211"><b>Where To File Paper Forms</b></p>
<p style="position:absolute;top:963px;left:475px;white-space:nowrap" class="ft210">Send this entire page with the entire Copy A page of Form(s) W-2 to:</p>
<p style="position:absolute;top:981px;left:528px;white-space:nowrap" class="ft213"><b>Social Security Administration &#160;</b></p>
<p style="position:absolute;top:997px;left:528px;white-space:nowrap" class="ft213"><b>Direct Operations Center &#160;</b></p>
<p style="position:absolute;top:1012px;left:528px;white-space:nowrap" class="ft213"><b>Wilkes-Barre, PA 18769-0001</b></p>
<p style="position:absolute;top:1032px;left:475px;white-space:nowrap" class="ft29"><b>Note:&#160;</b>If you use “Certified Mail” to file, change the ZIP code to<b>&#160;</b></p>
<p style="position:absolute;top:1045px;left:475px;white-space:nowrap" class="ft210">“18769-0002.” If you use an IRS-approved private delivery service, add</p>
<p style="position:absolute;top:1045px;left:857px;white-space:nowrap" class="ft29"><b>&#160;</b></p>
<p style="position:absolute;top:1058px;left:475px;white-space:nowrap" class="ft210">“ATTN: W-2 Process, 1150 E. Mountain Dr.” to the address and change</p>
<p style="position:absolute;top:1058px;left:859px;white-space:nowrap" class="ft29"><b>&#160;</b></p>
<p style="position:absolute;top:1071px;left:475px;white-space:nowrap" class="ft210">the ZIP code to “18702-7997.” See Pub. 15 (Circular E),</p>
<p style="position:absolute;top:1071px;left:774px;white-space:nowrap" class="ft29"><b>&#160;</b>Employer’s Tax&#160;</p>
<p style="position:absolute;top:1084px;left:475px;white-space:nowrap" class="ft210">Guide, for a list of IRS-approved private delivery services.</p>
<p style="position:absolute;top:1119px;left:219px;white-space:nowrap" class="ft29"><b>For Privacy Act and Paperwork Reduction Act Notice, see the separate instructions.</b></p>
<p style="position:absolute;top:1139px;left:420px;white-space:nowrap" class="ft214">Cat. No. 10159Y</p>
</div>

</div>
</body>


</html>




<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
 
<script>
 async function downloadPagesAsPDF() {
    const element1 = document.getElementById('page1-div');
    const element2 = document.getElementById('page2-div');
    
    if (!element1 || !element2) {
        alert('One or more elements not found');
        return;
    }

    const canvas1 = await html2canvas(element1, { scale: 2 });
    const canvas2 = await html2canvas(element2, { scale: 2 });

    const imgData1 = canvas1.toDataURL('image/jpeg', 1.0);
    const imgData2 = canvas2.toDataURL('image/jpeg', 1.0);

    const pdf = new jspdf.jsPDF({
        orientation: 'p',
        unit: 'px',
        format: [canvas1.width, canvas1.height]
    });

    pdf.addImage(imgData1, 'JPEG', 0, 0, canvas1.width, canvas1.height);
    pdf.addPage([canvas2.width, canvas2.height], 'p');
    pdf.addImage(imgData2, 'JPEG', 0, 0, canvas2.width, canvas2.height);

    pdf.save('W3Form.pdf');
}

</script>