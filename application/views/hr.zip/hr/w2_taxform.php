<?php error_reporting(1);  ?> 
<div class="content-wrapper">
   <section class="content-header" style="background-color: #ccc;">
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               p {margin: 0; padding: 0;}	
               .ft10{font-size:22px;font-family:Times;color:#ff0000;}
               .ft11{font-size:19px;font-family:Times;color:#000000;}
               .ft12{font-size:19px;font-family:Times;color:#0000ff;}
               .ft13{font-size:15px;font-family:Times;color:#000000;}
               .ft14{font-size:15px;font-family:Times;color:#000000;}
               .ft15{font-size:15px;font-family:Times;color:#0000ff;}
               .ft16{font-size:15px;line-height:32px;font-family:Times;color:#000000;}
            </style>
         </head>
         <button class="btnclr btn btn-default dropdown-toggle  boxes filip-horizontal mobile_para"  onclick="downloadPagesAsPDF()" style="margin-left:100px;" ><span  class="fa fa-download"></span>Download </button>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page1-div" style="position:relative;  width:918px;  height:1188px;  background: white;    margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target001.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:135px;left:402px;white-space:nowrap" class="ft10"><b>Attention:&#160;</b></p>
               <p style="position:absolute;top:178px;left:108px;white-space:nowrap; font-size: 23px !important;" class="ft11">You may file Forms W-2 and W-3 electronically on the SSA’s&#160;</p>
               <p style="position:absolute;top:178px;left:679px;white-space:nowrap; font-size: 22px !important;" class="ft12"><a style="color: #0000ff !important;" href="http://www.socialsecurity.gov/employer">Employer&#160;</a></p>
               <p style="position:absolute;top:203px;left:108px;white-space:nowrap; font-size: 22px !important;" class="ft12"><a style="color: #0000ff !important;" href="http://www.socialsecurity.gov/employer">W-2 Filing Instructions and Information</a></p>
               <p style="position:absolute;top:203px;left:467px;white-space:nowrap; font-size: 23px !important;" class="ft11">&#160;web page, which is also accessible&#160;</p>
               <p style="position:absolute;top:228px;left:108px;white-space:nowrap; font-size: 22px !important;" class="ft11"><a style="color: #0000ff !important;" href="http://www.socialsecurity.gov/employer">at&#160;</a></p>
               <p style="position:absolute;top:228px;left:131px;white-space:nowrap; font-size: 22px !important;" class="ft12"><a style="color: #0000ff !important;" href="http://www.socialsecurity.gov/employer">www.socialsecurity.gov/employer</a></p>
               <p style="position:absolute;top:228px;left:441px;white-space:nowrap; font-size: 22px !important;" class="ft11"><a style="color: #0000ff !important;" href="http://www.socialsecurity.gov/employer">. &#160;You can create fill-in versions of&#160;</a></p>
               <p style="position:absolute;top:253px;left:108px;white-space:nowrap; font-size: 23px !important;" class="ft11">Forms W-2 and W-3 for filing with SSA. You may also print out copies for&#160;</p>
               <p style="position:absolute;top:279px;left:108px;white-space:nowrap; font-size: 23px !important;" class="ft11">filing with state or local governments, distribution to your employees, and&#160;</p>
               <p style="position:absolute;top:304px;left:108px;white-space:nowrap; font-size: 23px !important;" class="ft11">for your records.</p>
               <p style="position:absolute;top:341px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft13"><b>Note:</b>&#160;Copy A of this form is provided for informational purposes only. Copy A appears in&#160;</p>
               <p style="position:absolute;top:361px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">red, similar to the official IRS form. The official printed version of this IRS form is scannable,&#160;</p>
               <p style="position:absolute;top:382px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">but the online version of it, printed from this website, is not. Do&#160;<b>not</b>&#160;print and file Copy A&#160;</p>
               <p style="position:absolute;top:403px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">downloaded from this website with the SSA; a&#160;<b>penalty</b>&#160;may be imposed for filing forms that&#160;</p>
               <p style="position:absolute;top:425px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">can’t be scanned. See the penalties section in the current&#160;<a style="color: #0000ff !important;" href="https://www.irs.gov/instructions/iw2w3/index-div">General Instructions for Forms&#160;W-2 and W-3</a></p>
               <p style="position:absolute;top:445px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">, available at&#160;<a style="color: #0000ff !important;" href="http://www.irs.gov/w2">www.irs.gov/w2</a>, for more information.</p>
               <p style="position:absolute;top:477px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">Please note that Copy B and other copies of this form, which appear in black, may be&#160;</p>
               <p style="position:absolute;top:498px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">downloaded, filled in, and printed and used to satisfy the requirement to provide the&#160;</p>
               <p style="position:absolute;top:519px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft16">information to the recipient.<br/>To order official IRS information returns such as Forms W-2 and W-3, which include a&#160;</p>
               <p style="position:absolute;top:572px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14"><a style="color: #0000ff !important;" href="https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns">scannable Copy A for filing, go to IRS’&#160;</a></p>
               <p style="position:absolute;top:570px;left:403px;white-space:nowrap; font-size: 18px !important;" class="ft15"><a style="color: #0000ff !important;" href="https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns">Online Ordering for Information Returns and&#160;</a></p>
               <p style="position:absolute;top:591px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft15"><a style="color: #0000ff !important;" href="https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns">Employer Returns</a></p>
               <p style="position:absolute;top:591px;left:246px;white-space:nowrap; font-size: 18px !important;" class="ft14"><a style="color: #0000ff !important;" href="http://www.irs.gov/orderforms">&#160;page, or visit&#160;</a></p>
               <p style="position:absolute;top:591px;left:353px;white-space:nowrap; font-size: 18px !important;" class="ft15"><a style="color: #0000ff !important;" href="http://www.irs.gov/orderforms">www.irs.gov/orderforms</a></p>
               <p style="position:absolute;top:593px;left:535px;white-space:nowrap; font-size: 18px !important;" class="ft14"><a style="color: #0000ff !important;" href="http://www.irs.gov/orderforms">&#160;and click on Employer and&#160;</a></p>
               <p style="position:absolute;top:613px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft16">Information returns. We’ll mail you the scannable forms and any other products you order.<br/>See IRS Publications&#160;</p>
               <p style="position:absolute;top:645px;left:275px;white-space:nowrap; font-size: 18px !important;" class="ft15"><a style="color: #0000ff !important;" href="http://www.irs.gov/pub1141">1141</a></p>
               <p style="position:absolute;top:645px;left:313px;white-space:nowrap; font-size: 18px !important;" class="ft14">,&#160;</p>
               <p style="position:absolute;top:645px;left:323px;white-space:nowrap; font-size: 18px !important;" class="ft15"><a style="color: #0000ff !important;" href="http://www.irs.gov/pub1167">1167</a></p>
               <p style="position:absolute;top:645px;left:361px;white-space:nowrap; font-size: 18px !important;" class="ft14"><a style="color: #0000ff !important;" href="http://www.irs.gov/pub1179">, and&#160;</a></p>
               <p style="position:absolute;top:645px;left:404px;white-space:nowrap; font-size: 18px !important;" class="ft15"><a style="color: #0000ff !important;" href="http://www.irs.gov/pub1179">1179</a></p>
               <p style="position:absolute;top:645px;left:443px;white-space:nowrap; font-size: 18px !important;" class="ft14"><a style="color: #0000ff !important;" href="http://www.irs.gov/pub1179">&#160;for more information about printing these tax&#160;</a></p>
               <p style="position:absolute;top:666px;left:108px;white-space:nowrap; font-size: 18px !important;" class="ft14">forms.</p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft20{font-size:10px;font-family:Times;color:#000000;}
                  .ft21{font-size:13px;font-family:Times;color:#000000;}
                  .ft22{font-size:8px;font-family:Times;color:#ff0000;}
                  .ft23{font-size:8px;font-family:Times;color:#ff0000;}
                  .ft24{font-size:4px;font-family:Times;color:#ff0000;}
                  .ft25{font-size:5px;font-family:Times;color:#ff0000;}
                  .ft26{font-size:34px;font-family:Times;color:#ff0000;}
                  .ft27{font-size:14px;font-family:Times;color:#ff0000;}
                  .ft28{font-size:34px;font-family:Times;color:#000000;}
                  .ft29{font-size:10px;font-family:Times;color:#ff0000;}
                  .ft210{font-size:10px;font-family:Times;color:#ff0000;}
                  .ft211{font-size:8px;line-height:12px;font-family:Times;color:#ff0000;}
                  .ft212{font-size:10px;line-height:14px;font-family:Times;color:#ff0000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page2-div" style="position:relative;width:918px;height:1188px;    margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target002.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:36px;left:54px;white-space:nowrap" class="ft20">&#160; &#160; &#160;</p>
               <p style="position:absolute;top:65px;left:76px;white-space:nowrap" class="ft21">22222</p>
               <p style="position:absolute;top:66px;left:164px;white-space:nowrap" class="ft22">VOID</p>
               


               <p style="position:absolute;top:56px;left:236px;white-space:nowrap" class="ft23"><b>a &#160;</b>Employee’s social security number<br> <span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['social_security_number']; ?></span></p>
               <p style="position:absolute;top:60px;left:430px;white-space:nowrap" class="ft211"><b>For Official Use Only&#160;<br/>OMB No. 1545-0008&#160;</b></p>
               <p style="position:absolute;top:92px;left:63px;white-space:nowrap" class="ft23"><b>b &#160;</b>Employer identification number (EIN) <br> <span style="color: #000; font-size: 14px;"><?php echo $c_details[0]['Federal_Pin_Number']; ?> </span></p>
               <p style="position:absolute;top:128px;left:63px;white-space:nowrap" class="ft23"><b>c &#160;</b>Employer’s name, address, and ZIP code <br><span style="color: #000; font-size: 14px;"><?php echo $getlocation[0]['address']; ?></span></p>
               <p style="position:absolute;top:236px;left:63px;white-space:nowrap" class="ft23"><b>d &#160;</b>Control number</p>
               <p style="position:absolute;top:272px;left:63px;white-space:nowrap" class="ft23"><b>e &#160;</b>Employee’s first name and initial <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['first_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:265px;white-space:nowrap" class="ft22">Last name <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['last_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:470px;white-space:nowrap" class="ft22">Suff.</p>
               <p style="position:absolute;top:416px;left:63px;white-space:nowrap" class="ft23"><b>f &#160;</b>Employee’s address and ZIP code <br><span style="color: #000; font-size: 14px; position: absolute; bottom: 18px;"><?php echo $e_details[0]['address_line_1']; ?> </span></p>
              
              
              
               <p style="position:absolute;top:92px;left:508px;white-space:nowrap" class="ft23"><b>1 &#160;&#160;</b>Wages, tips, other compensation <br>
                  <span style="color: #000; font-size: 14px;">
                  <?php
                     $overalltotal_amount = isset($get_payslip_info[0]['overalltotal_amount']) ? number_format($get_payslip_info[0]['overalltotal_amount'], 2) : 0.00;
                     echo '$'.$overalltotal_amount;
                     ?>
                  </span>
               </p>


               <?php
                  $overalltotal_amount = isset($get_payslip_info[0]['ftotal_amount']) ? number_format($get_payslip_info[0]['ftotal_amount'], 2) : '0.00';
                   ?>
               <p style="position:absolute;top:92px;left:692px;white-space:nowrap" class="ft23"><b>2 &#160;&#160;</b>Federal income tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>






               <?php
                  $stotal_amount = isset($get_payslip_info[0]['stotal_amount']) ? number_format($get_payslip_info[0]['stotal_amount'], 2) : '0';
                  ?>
               <p style="position:absolute;top:128px;left:508px;white-space:nowrap" class="ft23"><b>3 &#160;&#160;</b>Social security wages <br>
                  <span style="color: black;font-size: large;font-size: 14px;">
                  <?php
                     $overalltotal_amount = isset($get_payslip_info[0]['overalltotal_amount']) ? number_format($get_payslip_info[0]['overalltotal_amount'], 2) : 0.00;
                     echo '$'.$overalltotal_amount;
                     ?>
               </p>
               <p style="position:absolute;top:128px;left:692px;white-space:nowrap;color:red;" class="ft32"><b>4 &#160;&#160;</b>Social security tax withheld <br>
                  <span style="color: #000; font-size: 14px;">
                  $<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:164px;left:508px;white-space:nowrap" class="ft23"><b>5 &#160;&#160;</b>Medicare wages and tips <br><span style="color: #000; font-size: 14px;font-size: 14px;"><?php
                  $t_tax = isset($get_payslip_info[0]['overalltotal_amount']) ? number_format($get_payslip_info[0]['overalltotal_amount'],2): 0.00;
                  
                  
                  echo '$' .$t_tax;?></span></p>
               <?php
                  $mtotal_amount = isset($get_payslip_info[0]['mtotal_amount']) ? number_format($get_payslip_info[0]['mtotal_amount'], 2) : '0';
                  ?>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft23"><b>6 &#160;&#160;</b>Medicare tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>
               <p style="position:absolute;top:200px;left:508px;white-space:nowrap" class="ft23"><b>7 &#160;&#160;</b>Social security tips</p>
               <p style="position:absolute;top:200px;left:692px;white-space:nowrap" class="ft23"><b>8 &#160;&#160;</b>Allocated tips</p>
               <p style="position:absolute;top:236px;left:508px;white-space:nowrap" class="ft23"><b>9 &#160;&#160;</b></p>
               <p style="position:absolute;top:236px;left:686px;white-space:nowrap" class="ft23"><b>10 &#160;&#160;</b>Dependent care benefits</p>
               <p style="position:absolute;top:272px;left:503px;white-space:nowrap" class="ft23"><b>11 &#160;&#160;</b>Nonqualified plans</p>
               <p style="position:absolute;top:272px;left:686px;white-space:nowrap" class="ft23"><b>12a &#160;</b>See instructions for box 12</p>
               <p style="position:absolute;top:282px;left:687px;white-space:nowrap" class="ft24">C</p>
               <p style="position:absolute;top:287px;left:687px;white-space:nowrap" class="ft24">o&#160;</p>
               <p style="position:absolute;top:293px;left:687px;white-space:nowrap" class="ft24">d&#160;</p>
               <p style="position:absolute;top:298px;left:688px;white-space:nowrap" class="ft24">e</p>
               <p style="position:absolute;top:308px;left:686px;white-space:nowrap" class="ft23"><b>12b</b></p>
               <p style="position:absolute;top:318px;left:687px;white-space:nowrap" class="ft24">C</p>
               <p style="position:absolute;top:323px;left:687px;white-space:nowrap" class="ft24">o&#160;</p>
               <p style="position:absolute;top:329px;left:687px;white-space:nowrap" class="ft24">d&#160;</p>
               <p style="position:absolute;top:334px;left:688px;white-space:nowrap" class="ft24">e</p>
               <p style="position:absolute;top:344px;left:686px;white-space:nowrap" class="ft23"><b>12c</b></p>
               <p style="position:absolute;top:354px;left:687px;white-space:nowrap" class="ft24">C</p>
               <p style="position:absolute;top:359px;left:687px;white-space:nowrap" class="ft24">o&#160;</p>
               <p style="position:absolute;top:365px;left:687px;white-space:nowrap" class="ft24">d&#160;</p>
               <p style="position:absolute;top:370px;left:688px;white-space:nowrap" class="ft24">e</p>
               <p style="position:absolute;top:380px;left:686px;white-space:nowrap" class="ft23"><b>12d</b></p>
               <p style="position:absolute;top:390px;left:687px;white-space:nowrap" class="ft24">C</p>
               <p style="position:absolute;top:395px;left:687px;white-space:nowrap" class="ft24">o&#160;</p>
               <p style="position:absolute;top:401px;left:687px;white-space:nowrap" class="ft24">d&#160;</p>
               <p style="position:absolute;top:406px;left:688px;white-space:nowrap" class="ft24">e</p>
               <p style="position:absolute;top:308px;left:503px;white-space:nowrap" class="ft23"><b>13</b></p>
               <p style="position:absolute;top:307px;left:523px;white-space:nowrap" class="ft25">Statutory&#160;</p>
               <p style="position:absolute;top:315px;left:523px;white-space:nowrap" class="ft25">employee</p>
               <p style="position:absolute;top:307px;left:577px;white-space:nowrap" class="ft25">Retirement&#160;</p>
               <p style="position:absolute;top:315px;left:577px;white-space:nowrap" class="ft25">plan</p>
               <p style="position:absolute;top:307px;left:631px;white-space:nowrap" class="ft25">Third-party&#160;</p>
               <p style="position:absolute;top:315px;left:631px;white-space:nowrap" class="ft25">sick pay</p>
               
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap" class="ft23"><b>14 &#160;</b>Other
                <br>
                  <span style="color: black;font-size: 8px !important;font-size: 9px; top: 12px; left: -60px; ">
                  <?php foreach ($gettaxother_info as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 2);?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($other_tx as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 2); ?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($countyTax as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 2); ?>    <br>
                  </span>
                  <?php  endforeach; ?>
                  </span>
               </p>
               <?php
                  $matchedCode = '';
                  $matchedTaxType = '';
                  
                  $matchedCode1 = '';
                  $matchedTaxType1 = '';
                  
                  $matchedCode2 = '';
                  $matchedTaxType2 = '';
                  
                  
                  $matchedCode3 = '';
                  $matchedTaxType3 = '';
                  
                  foreach ($StatetaxType as $data) {
                      if ($data['tax_type'] === 'state_tax') {
                          $matchedCode = $data['code'];
                          $matchedTaxType = $data['tax_type'];
                          break;
                      }
                  }
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                      if ($datas['tax_type'] === 'living_state_tax') {
                          $matchedCode1 = $datas['code'];
                          $matchedTaxType1 = $datas['tax_type'];
                          break;
                      }
                  }
                  
                  
                   
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'living_local_tax') {
                      $matchedCode2 = $datas['code'];
                      $matchedTaxType2 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'local_tax') {
                      $matchedCode3 = $datas['code'];
                      $matchedTaxType3 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                    
                  ?>
               <p style="position:absolute;top:434px;left:57px;white-space:nowrap" class="ft23">
                  <b>15 &#160;</b> State &#160; Employer’s state ID number 
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative;">
                  <?php echo htmlspecialchars($matchedCode, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px;"><?php echo !empty($matchedCode) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative; top: 15px;">
                  <?php echo htmlspecialchars($matchedCode1, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px; top: 15px;"><?php echo !empty($matchedCode1) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?> </span>
                  
                 
                  
                  
               </p>
                <p style="position:absolute;top:434px;left:296px;white-space:nowrap; text-align: center;" class="ft23">
                    <b>16 &#160;</b>State wages, tips, etc <br>
                    <span style="color: #000; font-size: 14px; position: relative;left: 37px;"> 
                        <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                    </span>
                    <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                        <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                    </span> 
                </p>

 

                <?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }

                 ?>


               

               <?php
                  $overalltotal_statetaxworking = isset($stateworkingtax[0]['overalltotal_statetaxworking']) ? number_format($stateworkingtax[0]['overalltotal_statetaxworking'], 2) : '0';
                  ?>






               <p style="position:absolute;top:434px;left:427px;white-space:nowrap" class="ft23"><b>17 &#160;</b>State income tax
                  <br> 
                  
                  <span style="color: #000; font-size: 14px; position: relative;left: 37px;">
                    <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $overalltotal_statetax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>


                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">   
                    <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $overalltotal_statetaxworking, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>




               



               <p style="position:absolute;top:434px;left:545px;white-space:nowrap" class="ft23"><b>18 &#160;</b>Local wages, tips, etc
                  <br>
                  <span style="color: #000; font-size: 14px; position: relative;left: 37px;">
                    <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>





               <?php
                  $overalltotal_localtax = isset($localTax[0]['overalltotal_localtax']) ? number_format($localTax[0]['overalltotal_localtax'], 2) : '0';
                  ?>
               <?php
                  $livinglocaltax = isset($livinglocaldata[0]['livinglocaltax']) ? number_format($livinglocaldata[0]['livinglocaltax'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:674px;white-space:nowrap" class="ft23"><b>19 &#160;</b>Local income tax <br> 
                  <span style="color: black;font-size: large;font-size: 14px; position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $overalltotal_localtax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                    <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $livinglocaltax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>







               <p style="position:absolute;top:434px;left:793px;white-space:nowrap" class="ft23"><b>20 &#160;</b>Locality name <br> 
                  <span style="color: black;font-size: large;font-size: 14px; position: relative;left: 37px;"> 
                  <?php echo htmlspecialchars($matchedCode3, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
                  <br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;top: 9px;left: 37px; "> 
                  <?php echo htmlspecialchars($matchedCode2, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
               </p>







               <p style="position:absolute;top:528px;left:54px;white-space:nowrap" class="ft23"><b>Form</b></p>
               <p style="position:absolute;top:504px;left:86px;white-space:nowrap" class="ft26"><b>W-2</b></p>
               <p style="position:absolute;top:516px;left:160px;white-space:nowrap" class="ft27">Wage and Tax Statement</p>
               <p style="position:absolute;top:509px;left:434px;white-space:nowrap" class="ft28"><?php echo date('Y'); ?></p>
               <p style="position:absolute;top:513px;left:608px;white-space:nowrap" class="ft22">Department of the Treasury—Internal Revenue Service&#160;</p>
               <p style="position:absolute;top:529px;left:654px;white-space:nowrap" class="ft211"><b>For Privacy Act and Paperwork Reduction&#160;<br/></b>&#160;</p>
               <p style="position:absolute;top:541px;left:657px;white-space:nowrap" class="ft23"><b>Act Notice, see the separate instructions.&#160;</b></p>
               <p style="position:absolute;top:560px;left:786px;white-space:nowrap" class="ft22">Cat. No. 10134D</p>
               <p style="position:absolute;top:545px;left:54px;white-space:nowrap" class="ft212"><b>Copy A—For Social Security Administration.&#160;</b>Send this entire page with&#160;<br/>Form W-3 to the Social Security Administration; photocopies are&#160;</p>
               <p style="position:absolute;top:559px;left:403px;white-space:nowrap" class="ft29"><b>not&#160;</b>acceptable.</p>
               <p style="position:absolute;top:576px;left:284px;white-space:nowrap" class="ft27">Do Not Cut, Fold, or Staple Forms on This Page</p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft30{font-size:10px;font-family:Times;color:#000000;}
                  .ft31{font-size:13px;font-family:Times;color:#000000;}
                  .ft32{font-size:8px;font-family:Times;color:#000000;}
                  .ft33{font-size:8px;font-family:Times;color:#000000;}
                  .ft34{font-size:4px;font-family:Times;color:#000000;}
                  .ft35{font-size:5px;font-family:Times;color:#000000;}
                  .ft36{font-size:34px;font-family:Times;color:#000000;}
                  .ft37{font-size:14px;font-family:Times;color:#000000;}
                  .ft38{font-size:34px;font-family:Times;color:#000000;}
                  .ft39{font-size:10px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page3-div" style="position:relative;width:918px;height:1188px;    margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target003.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:36px;left:54px;white-space:nowrap" class="ft30">&#160; &#160; &#160;</p>
               <p style="position:absolute;top:65px;left:113px;white-space:nowrap" class="ft31">22222</p>
               <p style="position:absolute;top:56px;left:236px;white-space:nowrap" class="ft32"><b>a &#160;</b>Employee’s social security number<br> <span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['social_security_number']; ?></span></p>
               <p style="position:absolute;top:72px;left:430px;white-space:nowrap" class="ft32"><b>&#160;</b>OMB No. 1545-0008&#160;</p>
               <p style="position:absolute;top:92px;left:63px;white-space:nowrap" class="ft32"><b>b &#160;</b>Employer identification number (EIN) <br><span style="color: #000; font-size: 14px;"><?php echo htmlspecialchars($c_details[0]['Federal_Pin_Number'], ENT_QUOTES, 'UTF-8'); ?></span></p>
               <p style="position:absolute;top:128px;left:63px;white-space:nowrap" class="ft32"><b>c &#160;</b>Employer’s name, address, and ZIP code <br><span style="color: #000; font-size: 14px;"><?php echo $getlocation[0]['address']; ?></span></p>
               <p style="position:absolute;top:236px;left:63px;white-space:nowrap" class="ft32"><b>d &#160;</b>Control number</p>
               <p style="position:absolute;top:272px;left:63px;white-space:nowrap" class="ft32"><b>e &#160;</b>Employee’s first name and initial <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['first_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:265px;white-space:nowrap" class="ft33">Last name <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['last_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:470px;white-space:nowrap" class="ft33">Suff.</p>
               <p style="position:absolute;top:416px;left:63px;white-space:nowrap" class="ft32"><b>f &#160;</b>Employee’s address and ZIP code <br><span style="color: #000; font-size: 14px; position: absolute; bottom: 18px;"><?php echo $e_details[0]['address_line_1']; ?> </span></p>
              
              
              
              
               <p style="position:absolute;top:92px;left:508px;white-space:nowrap" class="ft32"><b>1 &#160;&#160;</b>Wages, tips, other compensation 
                  <br><span style="color: #000; font-size: 14px;"> 
                  <?php
                     $overalltotal_amount = isset($get_payslip_info[0]['overalltotal_amount']) ? number_format($get_payslip_info[0]['overalltotal_amount'], 2) : 0;
                     echo '$'.$overalltotal_amount;
                     ?>                  </span>
               </p>

               <?php
                  $overalltotal_amount = isset($get_payslip_info[0]['ftotal_amount']) ? number_format($get_payslip_info[0]['ftotal_amount'], 2) : '0';
                   ?>
               <p style="position:absolute;top:92px;left:692px;white-space:nowrap" class="ft32"><b>2 &#160;&#160;</b>Federal income tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>




 





















               <p style="position:absolute;top:128px;left:508px;white-space:nowrap" class="ft32"><b>3 &#160;&#160;</b>Social security wages <br><span style="color: #000; font-size: 14px;"><?php 
                  $S_tax = 0; 
                  $S_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo  '$' .$S_tax;
                  ?></span></p>



               <p style="position:absolute;top:128px;left:692px;white-space:nowrap" class="ft32"><b>4 &#160;&#160;</b>Social security tax withheld <br>
                  <span style="color: #000; font-size: 14px;">
                  $<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>



               <p style="position:absolute;top:164px;left:508px;white-space:nowrap" class="ft32"><b>5 &#160;&#160;</b>Medicare wages and tips <br><span style="color: #000; font-size: 14px;"><?php 
                  $t_tax = 0; 
                  $t_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$'.$t_tax;
                  ?></span></p>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft32"><b>6 &#160;&#160;</b>Medicare tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>
               <p style="position:absolute;top:200px;left:508px;white-space:nowrap" class="ft32"><b>7 &#160;&#160;</b>Social security tips</p>
               <p style="position:absolute;top:200px;left:692px;white-space:nowrap" class="ft32"><b>8 &#160;&#160;</b>Allocated tips</p>
               <p style="position:absolute;top:236px;left:508px;white-space:nowrap" class="ft32"><b>9 &#160;&#160;</b></p>
               <p style="position:absolute;top:236px;left:686px;white-space:nowrap" class="ft32"><b>10 &#160;&#160;</b>Dependent care benefits</p>
               <p style="position:absolute;top:272px;left:503px;white-space:nowrap" class="ft32"><b>11 &#160;&#160;</b>Nonqualified plans</p>
               <p style="position:absolute;top:272px;left:686px;white-space:nowrap" class="ft32"><b>12a &#160;</b></p>
               <p style="position:absolute;top:282px;left:687px;white-space:nowrap" class="ft34">C</p>
               <p style="position:absolute;top:287px;left:687px;white-space:nowrap" class="ft34">o&#160;</p>
               <p style="position:absolute;top:293px;left:687px;white-space:nowrap" class="ft34">d&#160;</p>
               <p style="position:absolute;top:298px;left:688px;white-space:nowrap" class="ft34">e</p>
               <p style="position:absolute;top:308px;left:686px;white-space:nowrap" class="ft32"><b>12b</b></p>
               <p style="position:absolute;top:318px;left:687px;white-space:nowrap" class="ft34">C</p>
               <p style="position:absolute;top:323px;left:687px;white-space:nowrap" class="ft34">o&#160;</p>
               <p style="position:absolute;top:329px;left:687px;white-space:nowrap" class="ft34">d&#160;</p>
               <p style="position:absolute;top:334px;left:688px;white-space:nowrap" class="ft34">e</p>
               <p style="position:absolute;top:344px;left:686px;white-space:nowrap" class="ft32"><b>12c</b></p>
               <p style="position:absolute;top:354px;left:687px;white-space:nowrap" class="ft34">C</p>
               <p style="position:absolute;top:359px;left:687px;white-space:nowrap" class="ft34">o&#160;</p>
               <p style="position:absolute;top:365px;left:687px;white-space:nowrap" class="ft34">d&#160;</p>
               <p style="position:absolute;top:370px;left:688px;white-space:nowrap" class="ft34">e</p>
               <p style="position:absolute;top:380px;left:686px;white-space:nowrap" class="ft32"><b>12d</b></p>
               <p style="position:absolute;top:390px;left:687px;white-space:nowrap" class="ft34">C</p>
               <p style="position:absolute;top:395px;left:687px;white-space:nowrap" class="ft34">o&#160;</p>
               <p style="position:absolute;top:401px;left:687px;white-space:nowrap" class="ft34">d&#160;</p>
               <p style="position:absolute;top:406px;left:688px;white-space:nowrap" class="ft34">e</p>
               <p style="position:absolute;top:308px;left:503px;white-space:nowrap" class="ft32"><b>13</b></p>
               <p style="position:absolute;top:307px;left:523px;white-space:nowrap" class="ft35">Statutory&#160;</p>
               <p style="position:absolute;top:315px;left:523px;white-space:nowrap" class="ft35">employee</p>
               <p style="position:absolute;top:307px;left:577px;white-space:nowrap" class="ft35">Retirement&#160;</p>
               <p style="position:absolute;top:315px;left:577px;white-space:nowrap" class="ft35">plan</p>
               <p style="position:absolute;top:307px;left:631px;white-space:nowrap" class="ft35">Third-party&#160;</p>
               <p style="position:absolute;top:315px;left:631px;white-space:nowrap" class="ft35">sick pay</p>
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap" class="ft32"><b>14 &#160;</b>Other</p>
              
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap ;" class="ft32"><b>14 &#160;</b>Other
               <br>
               <span style="color: black;font-size: 8px !important;font-size: 9px; top: 12px; left: -60px; ">
                  <?php foreach ($gettaxother_info as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 2);?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($other_tx as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 2); ?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($countyTax as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 2); ?>    <br>
                  </span>
                  <?php  endforeach; ?>
                  </span>
               </p>
               <?php
                  $matchedCode = '';
                  $matchedTaxType = '';
                  
                  $matchedCode1 = '';
                  $matchedTaxType1 = '';
                  
                  $matchedCode2 = '';
                  $matchedTaxType2 = '';
                  
                  
                  $matchedCode3 = '';
                  $matchedTaxType3 = '';
                  
                  foreach ($StatetaxType as $data) {
                      if ($data['tax_type'] === 'state_tax') {
                          $matchedCode = $data['code'];
                          $matchedTaxType = $data['tax_type'];
                          break;
                      }
                  }
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                      if ($datas['tax_type'] === 'living_state_tax') {
                          $matchedCode1 = $datas['code'];
                          $matchedTaxType1 = $datas['tax_type'];
                          break;
                      }
                  }
                  
                  
                   
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'living_local_tax') {
                      $matchedCode2 = $datas['code'];
                      $matchedTaxType2 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'local_tax') {
                      $matchedCode3 = $datas['code'];
                      $matchedTaxType3 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                    
                  ?>
               <p style="position:absolute;top:434px;left:57px;white-space:nowrap" class="ft32">
                  <b>15 &#160;</b> State &#160; Employer’s state ID number 
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative;">
                  <?php echo htmlspecialchars($matchedCode, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  
                  
                  
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px;">
<?php echo !empty($matchedCode) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                
                
                  <br>
                  
                  
                  
                  <span style="color: #000; font-size: 14px; position: relative; top: 15px;">
                  <?php echo htmlspecialchars($matchedCode1, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px; top: 15px;"><?php echo !empty($matchedCode1) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
               </p>
               
               
               
               
               <p style="position:absolute;top:434px;left:296px;white-space:nowrap" class="ft32"><b>16 &#160;</b>State wages, tips, etc 
                  <br><span style="color: #000; font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>
               <?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }

                 ?>
                <?php
                  $overalltotal_statetaxworking = isset($stateworkingtax[0]['overalltotal_statetaxworking']) ? number_format($stateworkingtax[0]['overalltotal_statetaxworking'], 2) : '0';
                ?>
               <p style="position:absolute;top:434px;left:427px;white-space:nowrap" class="ft32"><b>17 &#160;</b>State income tax 
                  <br> <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $overalltotal_statetax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $overalltotal_statetaxworking, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:545px;white-space:nowrap" class="ft32"><b>18 &#160;</b>Local wages, tips, etc
                  <br>
                  <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span> 
               </p>
                <?php
                  $overalltotal_localtax = isset($localTax[0]['overalltotal_localtax']) ? number_format($localTax[0]['overalltotal_localtax'], 2) : '0';
                  ?>
                <?php
                  $livinglocaltax = isset($livinglocaldata[0]['livinglocaltax']) ? number_format($livinglocaldata[0]['livinglocaltax'], 2) : '0';
                ?>
               <p style="position:absolute;top:434px;left:674px;white-space:nowrap" class="ft32"><b>19 &#160;</b>Local income tax<br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $overalltotal_localtax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $livinglocaltax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>  
               </p>
               <p style="position:absolute;top:434px;left:793px;white-space:nowrap" class="ft32"><b>20 &#160;</b>Locality name <br> 
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo htmlspecialchars($matchedCode3, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
                  <br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;top: 9px;left: 37px; "> 
                  <?php echo htmlspecialchars($matchedCode2, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
               </p>





               <p style="position:absolute;top:528px;left:54px;white-space:nowrap" class="ft32"><b>Form</b></p>
               <p style="position:absolute;top:504px;left:86px;white-space:nowrap" class="ft36"><b>W-2</b></p>
               <p style="position:absolute;top:516px;left:160px;white-space:nowrap" class="ft37">Wage and Tax Statement</p>
               <p style="position:absolute;top:509px;left:434px;white-space:nowrap" class="ft38"><?php echo date('Y'); ?></p>
               <p style="position:absolute;top:513px;left:608px;white-space:nowrap" class="ft33">Department of the Treasury—Internal Revenue Service</p>
               <p style="position:absolute;top:544px;left:54px;white-space:nowrap" class="ft39"><b>Copy 1—For State, City, or Local Tax Department</b></p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft40{font-size:10px;font-family:Times;color:#000000;}
                  .ft41{font-size:8px;font-family:Times;color:#000000;}
                  .ft42{font-size:8px;font-family:Times;color:#000000;}
                  .ft43{font-size:8px;font-family:Times;color:#000000;}
                  .ft44{font-size:4px;font-family:Times;color:#000000;}
                  .ft45{font-size:5px;font-family:Times;color:#000000;}
                  .ft46{font-size:34px;font-family:Times;color:#000000;}
                  .ft47{font-size:14px;font-family:Times;color:#000000;}
                  .ft48{font-size:34px;font-family:Times;color:#000000;}
                  .ft49{font-size:10px;font-family:Times;color:#000000;}
                  .ft410{font-size:8px;line-height:12px;font-family:Times;color:#000000;}
                  .ft411{font-size:8px;line-height:12px;font-family:Times;color:#000000;}
                  .ft412{font-size:10px;line-height:14px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page4-div" style="position:relative;width:918px;height:1188px;    margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target004.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:36px;left:54px;white-space:nowrap" class="ft40">&#160; &#160; &#160;</p>
               <p style="position:absolute;top:56px;left:236px;white-space:nowrap" class="ft41"><b>a &#160;</b>Employee’s social security number<br> <span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['social_security_number']; ?></span></p>
               <p style="position:absolute;top:72px;left:430px;white-space:nowrap" class="ft41"><b>&#160;</b>OMB No. 1545-0008&#160;</p>
               <p style="position:absolute;top:57px;left:543px;white-space:nowrap" class="ft410"><b>Safe, accurate,&#160;<br/>FAST! Use</b></p>
               <p style="position:absolute;top:58px;left:751px;white-space:nowrap" class="ft411">Visit the IRS website at&#160;<br/><i><b>www.irs.gov/efile</b></i>.</p>
               <p style="position:absolute;top:92px;left:63px;white-space:nowrap" class="ft41"><b>b &#160;</b>Employer identification number (EIN) <br> <span style="color: #000; font-size: 14px;"><?php echo htmlspecialchars($c_details[0]['Federal_Pin_Number'], ENT_QUOTES, 'UTF-8'); ?></span></p>
               <p style="position:absolute;top:128px;left:63px;white-space:nowrap" class="ft41"><b>c &#160;</b>Employer’s name, address, and ZIP code <br><span style="color: #000; font-size: 14px;"><?php echo $getlocation[0]['address']; ?></span></p>
               <p style="position:absolute;top:236px;left:63px;white-space:nowrap" class="ft41"><b>d &#160;</b>Control number</p>
               <p style="position:absolute;top:272px;left:63px;white-space:nowrap" class="ft41"><b>e &#160;</b>Employee’s first name and initial <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['first_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:265px;white-space:nowrap" class="ft42">Last name <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['last_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:470px;white-space:nowrap" class="ft42">Suff.</p>
               <p style="position:absolute;top:416px;left:63px;white-space:nowrap" class="ft41"><b>f &#160;</b>Employee’s address and ZIP code <br><span style="color: #000; font-size: 14px; position: absolute; bottom: 18px;"><?php echo $e_details[0]['address_line_1']; ?> </span></p>
               <p style="position:absolute;top:92px;left:508px;white-space:nowrap" class="ft41"><b>1 &#160;&#160;</b>Wages, tips, other compensation 
                  <br><span style="color: #000; font-size: 14px;"> 
                  $<?php echo htmlspecialchars($t_tax, ENT_QUOTES, 'UTF-8'); ?> 
                  </span>
               </p>
               <p style="position:absolute;top:92px;left:692px;white-space:nowrap" class="ft41"><b>2 &#160;&#160;</b>Federal income tax withheld<br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:128px;left:508px;white-space:nowrap" class="ft41"><b>3 &#160;&#160;</b>Social security wages <br><span style="color: #000; font-size: 14px;"><?php 
                  $S_tax = 0; 
                  $S_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$' .$S_tax;
                  ?></span></p>
               <p style="position:absolute;top:128px;left:692px;white-space:nowrap" class="ft41"><b>4 &#160;&#160;</b>Social security tax withheld <br>
                  <span style="color: #000; font-size: 14px;">
                  $<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:164px;left:508px;white-space:nowrap" class="ft41"><b>5 &#160;&#160;</b>Medicare wages and tips <br><span style="color: #000; font-size: 14px;"><?php 
                  $t_tax = 0; 
                  $t_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$'. $t_tax;
                  ?></span></p>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft41"><b>6 &#160;&#160;</b>Medicare tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>
               <p style="position:absolute;top:200px;left:508px;white-space:nowrap" class="ft41"><b>7 &#160;&#160;</b>Social security tips</p>
               <p style="position:absolute;top:200px;left:692px;white-space:nowrap" class="ft41"><b>8 &#160;&#160;</b>Allocated tips</p>
               <p style="position:absolute;top:236px;left:508px;white-space:nowrap" class="ft41"><b>9 &#160;&#160;</b></p>
               <p style="position:absolute;top:236px;left:686px;white-space:nowrap" class="ft41"><b>10 &#160;&#160;</b>Dependent care benefits</p>
               <p style="position:absolute;top:272px;left:503px;white-space:nowrap" class="ft41"><b>11 &#160;&#160;</b>Nonqualified plans</p>
               <p style="position:absolute;top:272px;left:686px;white-space:nowrap" class="ft41"><b>12a&#160;</b>See instructions for box 12</p>
               <p style="position:absolute;top:282px;left:687px;white-space:nowrap" class="ft44">C</p>
               <p style="position:absolute;top:287px;left:687px;white-space:nowrap" class="ft44">o&#160;</p>
               <p style="position:absolute;top:293px;left:687px;white-space:nowrap" class="ft44">d&#160;</p>
               <p style="position:absolute;top:298px;left:688px;white-space:nowrap" class="ft44">e</p>
               <p style="position:absolute;top:308px;left:686px;white-space:nowrap" class="ft41"><b>12b</b></p>
               <p style="position:absolute;top:318px;left:687px;white-space:nowrap" class="ft44">C</p>
               <p style="position:absolute;top:323px;left:687px;white-space:nowrap" class="ft44">o&#160;</p>
               <p style="position:absolute;top:329px;left:687px;white-space:nowrap" class="ft44">d&#160;</p>
               <p style="position:absolute;top:334px;left:688px;white-space:nowrap" class="ft44">e</p>
               <p style="position:absolute;top:344px;left:686px;white-space:nowrap" class="ft41"><b>12c</b></p>
               <p style="position:absolute;top:354px;left:687px;white-space:nowrap" class="ft44">C</p>
               <p style="position:absolute;top:359px;left:687px;white-space:nowrap" class="ft44">o&#160;</p>
               <p style="position:absolute;top:365px;left:687px;white-space:nowrap" class="ft44">d&#160;</p>
               <p style="position:absolute;top:370px;left:688px;white-space:nowrap" class="ft44">e</p>
               <p style="position:absolute;top:380px;left:686px;white-space:nowrap" class="ft41"><b>12d</b></p>
               <p style="position:absolute;top:390px;left:687px;white-space:nowrap" class="ft44">C</p>
               <p style="position:absolute;top:395px;left:687px;white-space:nowrap" class="ft44">o&#160;</p>
               <p style="position:absolute;top:401px;left:687px;white-space:nowrap" class="ft44">d&#160;</p>
               <p style="position:absolute;top:406px;left:688px;white-space:nowrap" class="ft44">e</p>
               <p style="position:absolute;top:308px;left:503px;white-space:nowrap" class="ft41"><b>13</b></p>
               <p style="position:absolute;top:307px;left:523px;white-space:nowrap" class="ft45">Statutory&#160;</p>
               <p style="position:absolute;top:315px;left:523px;white-space:nowrap" class="ft45">employee</p>
               <p style="position:absolute;top:307px;left:577px;white-space:nowrap" class="ft45">Retirement&#160;</p>
               <p style="position:absolute;top:315px;left:577px;white-space:nowrap" class="ft45">plan</p>
               <p style="position:absolute;top:307px;left:631px;white-space:nowrap" class="ft45">Third-party&#160;</p>
               <p style="position:absolute;top:315px;left:631px;white-space:nowrap" class="ft45">sick pay</p>
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap" class="ft45"><b>  &#160;</b> </p>
               
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap ;" class="ft32"><b>14 &#160;</b>Other
                  <br>
                  <span style="color: black;font-size: 8px !important;font-size: 9px; top: 12px; left: -60px; ">
                  <?php foreach ($gettaxother_info as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4);?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($other_tx as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4); ?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($countyTax as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4); ?>    <br>
                  </span>
                  <?php  endforeach; ?>
                  </span>
               </p>
               <?php
                  $matchedCode = '';
                  $matchedTaxType = '';
                  
                  $matchedCode1 = '';
                  $matchedTaxType1 = '';
                  
                  $matchedCode2 = '';
                  $matchedTaxType2 = '';
                  
                  
                  $matchedCode3 = '';
                  $matchedTaxType3 = '';
                  
                  foreach ($StatetaxType as $data) {
                      if ($data['tax_type'] === 'state_tax') {
                          $matchedCode = $data['code'];
                          $matchedTaxType = $data['tax_type'];
                          break;
                      }
                  }
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                      if ($datas['tax_type'] === 'living_state_tax') {
                          $matchedCode1 = $datas['code'];
                          $matchedTaxType1 = $datas['tax_type'];
                          break;
                      }
                  }
                  
                  
                   
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'living_local_tax') {
                      $matchedCode2 = $datas['code'];
                      $matchedTaxType2 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'local_tax') {
                      $matchedCode3 = $datas['code'];
                      $matchedTaxType3 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                    
                  ?>

               <p style="position:absolute;top:434px;left:57px;white-space:nowrap" class="ft41"><b>15 &#160;</b>State&#160;Employer’s state ID number
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative;">
                  <?php echo htmlspecialchars($matchedCode, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px;"><?php echo !empty($matchedCode) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?>
</span>
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative; top: 15px;">
                  <?php echo htmlspecialchars($matchedCode1, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px; top: 15px;"><?php echo !empty($matchedCode1) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?>
</span>
               </p>

               <p style="position:absolute;top:434px;left:296px;white-space:nowrap" class="ft41"><b>16 &#160;</b>State wages, tips, etc 
                  <br><span style="color: #000; font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>   
                  </span>
               </p>
             


<?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }

                 ?>









               <?php
                  $overalltotal_statetaxworking = isset($stateworkingtax[0]['overalltotal_statetaxworking']) ? number_format($stateworkingtax[0]['overalltotal_statetaxworking'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:427px;white-space:nowrap" class="ft41"><b>17 &#160;</b>State income tax 
                  <br> <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $overalltotal_statetax, ENT_QUOTES, 'UTF-8') : ''; ?>   
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $overalltotal_statetaxworking, ENT_QUOTES, 'UTF-8') : ''; ?>    
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:545px;white-space:nowrap" class="ft41"><b>18 &#160;</b>Local wages, tips, etc
                  <br>
                  <span style="color: #000; font-size: 14px; position: relative;left: 37px;">
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>
               </p>
               <?php
                  $overalltotal_localtax = isset($localTax[0]['overalltotal_localtax']) ? number_format($localTax[0]['overalltotal_localtax'], 2) : '0';
                  ?>
               <?php
                  $livinglocaltax = isset($livinglocaldata[0]['livinglocaltax']) ? number_format($livinglocaldata[0]['livinglocaltax'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:674px;white-space:nowrap" class="ft41"><b>19 &#160;</b>Local income tax 
               	  <br> 
                  <span style="color: black;font-size: large;font-size: 14px; position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $overalltotal_localtax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $livinglocaltax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:793px;white-space:nowrap" class="ft41"><b>20 &#160;</b>Locality name
               	<br>
                  <span style="color: black;font-size: large;font-size: 14px; position: relative;left: 37px;"> 
                  <?php echo htmlspecialchars($matchedCode3, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
                  <br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;top: 9px;left: 37px; "> 
                  <?php echo htmlspecialchars($matchedCode2, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
               </p>
               <p style="position:absolute;top:528px;left:54px;white-space:nowrap" class="ft41"><b>Form</b></p>
               <p style="position:absolute;top:504px;left:86px;white-space:nowrap" class="ft46"><b>W-2</b></p>
               <p style="position:absolute;top:516px;left:160px;white-space:nowrap" class="ft47">Wage and Tax Statement</p>
               <p style="position:absolute;top:509px;left:434px;white-space:nowrap" class="ft48"><?php echo date('Y'); ?></p>
               <p style="position:absolute;top:513px;left:608px;white-space:nowrap" class="ft42">Department of the Treasury—Internal Revenue Service</p>
               <p style="position:absolute;top:545px;left:54px;white-space:nowrap" class="ft412"><b>Copy B—To Be Filed With Employee’s FEDERAL Tax Return.&#160;<br/></b>This information is being furnished to the Internal Revenue Service.</p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft50{font-size:11px;font-family:Times;color:#000000;}
                  .ft51{font-size:11px;font-family:Times;color:#000000;}
                  .ft52{font-size:11px;font-family:Times;color:#000000;}
                  .ft53{font-size:16px;font-family:Times;color:#000000;}
                  .ft54{font-size:11px;line-height:18px;font-family:Times;color:#000000;}
                  .ft55{font-size:11px;line-height:19px;font-family:Times;color:#000000;}
                  .ft56{font-size:11px;line-height:18px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page5-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target005.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:50px;left:54px;white-space:nowrap" class="ft50"><b>Future developments.</b>&#160;For the latest information about&#160;</p>
               <p style="position:absolute;top:65px;left:54px;white-space:nowrap" class="ft51">developments related to Form W-2, such as legislation enacted&#160;</p>
               <p style="position:absolute;top:80px;left:54px;white-space:nowrap" class="ft51">after it was published, go to&#160;<i>www.irs.gov/FormW2</i>.</p>
               <p style="position:absolute;top:105px;left:54px;white-space:nowrap" class="ft53"><b>Notice to Employee</b></p>
               <p style="position:absolute;top:130px;left:54px;white-space:nowrap" class="ft50"><b>Do you have to file?</b>&#160;Refer to the Form 1040 instructions to&#160;</p>
               <p style="position:absolute;top:145px;left:54px;white-space:nowrap" class="ft51">determine if you are required to file a tax return. Even if you&#160;</p>
               <p style="position:absolute;top:160px;left:54px;white-space:nowrap" class="ft51">don’t have to file a tax return, you may be eligible for a refund if&#160;</p>
               <p style="position:absolute;top:175px;left:54px;white-space:nowrap" class="ft54">box 2 shows an amount or if you are eligible for any credit.&#160;<br/><b>Earned income tax credit (EITC).&#160;</b>You may be able to take the&#160;</p>
               <p style="position:absolute;top:208px;left:54px;white-space:nowrap" class="ft51">EITC for 2024 if your adjusted gross income (AGI) is less than a&#160;</p>
               <p style="position:absolute;top:223px;left:54px;white-space:nowrap" class="ft51">certain amount. The amount of the credit is based on income&#160;</p>
               <p style="position:absolute;top:238px;left:54px;white-space:nowrap" class="ft51">and family size. Workers without children could qualify for a&#160;</p>
               <p style="position:absolute;top:252px;left:54px;white-space:nowrap" class="ft51">smaller credit. You and any qualifying children must have valid&#160;</p>
               <p style="position:absolute;top:267px;left:54px;white-space:nowrap" class="ft51">social security numbers (SSNs). You can’t take the EITC if your&#160;</p>
               <p style="position:absolute;top:281px;left:54px;white-space:nowrap" class="ft51">investment income is more than the specified amount for 2024&#160;</p>
               <p style="position:absolute;top:296px;left:54px;white-space:nowrap" class="ft51">or if income is earned for services provided while you were an&#160;</p>
               <p style="position:absolute;top:311px;left:54px;white-space:nowrap" class="ft51">inmate at a penal institution. For 2024 income limits and more&#160;</p>
               <p style="position:absolute;top:325px;left:54px;white-space:nowrap" class="ft51">information, visit&#160;<i>www.irs.gov/EITC</i>. See also Pub. 596.&#160;</p>
               <p style="position:absolute;top:325px;left:390px;white-space:nowrap" class="ft50"><b>Any&#160;</b></p>
               <p style="position:absolute;top:340px;left:54px;white-space:nowrap" class="ft50"><b>EITC that is more than your tax liability is refunded to you,&#160;</b></p>
               <p style="position:absolute;top:354px;left:54px;white-space:nowrap" class="ft55"><b>but only if you file a tax return.<br/>Employee’s social security number (SSN).</b>&#160;For your&#160;</p>
               <p style="position:absolute;top:388px;left:54px;white-space:nowrap" class="ft51">protection, this form may show only the last four digits of your&#160;</p>
               <p style="position:absolute;top:403px;left:54px;white-space:nowrap" class="ft51">SSN. However, your employer has reported your complete SSN&#160;</p>
               <p style="position:absolute;top:417px;left:54px;white-space:nowrap" class="ft54">to the IRS and the Social Security Administration (SSA).<br/><b>Clergy and religious workers.&#160;</b>If you aren’t subject to<b>&#160;</b>social&#160;</p>
               <p style="position:absolute;top:451px;left:54px;white-space:nowrap" class="ft51">security and Medicare taxes, see Pub. 517.</p>
               <p style="position:absolute;top:50px;left:475px;white-space:nowrap" class="ft50"><b>Corrections.&#160;</b>If your name, SSN, or address is incorrect,<b>&#160;</b>correct&#160;</p>
               <p style="position:absolute;top:65px;left:475px;white-space:nowrap" class="ft51">Copies B, C, and 2 and ask your employer to correct</p>
               <p style="position:absolute;top:65px;left:793px;white-space:nowrap" class="ft50"><b>&#160;</b>your&#160;</p>
               <p style="position:absolute;top:80px;left:475px;white-space:nowrap" class="ft51">employment record. Be sure to ask the employer to file Form&#160;</p>
               <p style="position:absolute;top:95px;left:475px;white-space:nowrap" class="ft51">W-2c, Corrected Wage and Tax Statement, with the</p>
               <p style="position:absolute;top:94px;left:788px;white-space:nowrap" class="ft50"><b>&#160;</b>SSA to&#160;</p>
               <p style="position:absolute;top:109px;left:475px;white-space:nowrap" class="ft51">correct any name,</p>
               <p style="position:absolute;top:109px;left:584px;white-space:nowrap" class="ft50"><b>&#160;</b>SSN, or money amount error reported to the&#160;</p>
               <p style="position:absolute;top:124px;left:475px;white-space:nowrap" class="ft51">SSA on Form</p>
               <p style="position:absolute;top:124px;left:556px;white-space:nowrap" class="ft50"><b>&#160;</b>W-2. Be sure to get your copies of Form W-2c&#160;</p>
               <p style="position:absolute;top:138px;left:475px;white-space:nowrap" class="ft51">from your employer for all corrections made so you may file&#160;</p>
               <p style="position:absolute;top:153px;left:475px;white-space:nowrap" class="ft51">them with your tax return. If your name and SSN are correct but&#160;</p>
               <p style="position:absolute;top:168px;left:475px;white-space:nowrap" class="ft51">aren’t the same</p>
               <p style="position:absolute;top:167px;left:569px;white-space:nowrap" class="ft50"><b>&#160;</b>as shown on your social security card, you&#160;</p>
               <p style="position:absolute;top:182px;left:475px;white-space:nowrap" class="ft51">should ask for a</p>
               <p style="position:absolute;top:182px;left:571px;white-space:nowrap" class="ft50"><b>&#160;</b>new card that displays your correct name at&#160;</p>
               <p style="position:absolute;top:197px;left:475px;white-space:nowrap" class="ft51">any SSA office</p>
               <p style="position:absolute;top:197px;left:564px;white-space:nowrap" class="ft50"><b>&#160;</b>or by calling 800-772-1213. You may also visit&#160;</p>
               <p style="position:absolute;top:212px;left:475px;white-space:nowrap" class="ft56">the SSA website at&#160;<i>www.SSA.gov.<br/></i><b>Cost of employer-sponsored health coverage (if such cost is&#160;</b></p>
               <p style="position:absolute;top:245px;left:475px;white-space:nowrap" class="ft50"><b>provided by the employer).&#160;</b>The reporting in box 12, using&#160;</p>
               <p style="position:absolute;top:260px;left:475px;white-space:nowrap" class="ft51">code DD, of the cost of employer-sponsored health coverage is&#160;</p>
               <p style="position:absolute;top:275px;left:475px;white-space:nowrap" class="ft51">for your information only.&#160;</p>
               <p style="position:absolute;top:274px;left:630px;white-space:nowrap" class="ft50"><b>The amount reported with code DD&#160;</b></p>
               <p style="position:absolute;top:289px;left:475px;white-space:nowrap" class="ft55"><b>is not taxable.<br/>Credit for excess taxes.&#160;</b>If you had more than one<b>&#160;</b>employer in&#160;</p>
               <p style="position:absolute;top:323px;left:475px;white-space:nowrap" class="ft51">2024 and more than $10,453.20 in social security</p>
               <p style="position:absolute;top:323px;left:772px;white-space:nowrap" class="ft50"><b>&#160;</b>and/or Tier 1&#160;</p>
               <p style="position:absolute;top:338px;left:475px;white-space:nowrap" class="ft51">railroad retirement (RRTA) taxes were withheld,</p>
               <p style="position:absolute;top:337px;left:759px;white-space:nowrap" class="ft50"><b>&#160;</b>you may be able&#160;</p>
               <p style="position:absolute;top:352px;left:475px;white-space:nowrap" class="ft51">to claim a credit for the excess against</p>
               <p style="position:absolute;top:352px;left:708px;white-space:nowrap" class="ft50"><b>&#160;</b>your federal income tax.&#160;</p>
               <p style="position:absolute;top:367px;left:475px;white-space:nowrap" class="ft51">See the Form 1040 instructions. If you had more than one&#160;</p>
               <p style="position:absolute;top:381px;left:475px;white-space:nowrap" class="ft51">railroad</p>
               <p style="position:absolute;top:381px;left:520px;white-space:nowrap" class="ft50"><b>&#160;</b>employer and more than $6,129.90 in Tier 2 RRTA tax&#160;</p>
               <p style="position:absolute;top:396px;left:475px;white-space:nowrap" class="ft51">was</p>
               <p style="position:absolute;top:396px;left:499px;white-space:nowrap" class="ft50"><b>&#160;</b>withheld, you may be able to claim a refund on Form 843.&#160;</p>
               <p style="position:absolute;top:411px;left:475px;white-space:nowrap" class="ft51">See the Instructions for Form 843.</p>
               <p style="position:absolute;top:430px;left:489px;white-space:nowrap" class="ft51">(See also&#160;<i>Instructions for Employee&#160;</i>on the back of Copy C.)</p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft60{font-size:10px;font-family:Times;color:#000000;}
                  .ft61{font-size:8px;font-family:Times;color:#000000;}
                  .ft62{font-size:8px;font-family:Times;color:#000000;}
                  .ft63{font-size:4px;font-family:Times;color:#000000;}
                  .ft64{font-size:5px;font-family:Times;color:#000000;}
                  .ft65{font-size:34px;font-family:Times;color:#000000;}
                  .ft66{font-size:14px;font-family:Times;color:#000000;}
                  .ft67{font-size:34px;font-family:Times;color:#000000;}
                  .ft68{font-size:10px;font-family:Times;color:#000000;}
                  .ft69{font-size:10px;font-family:Times;color:#000000;}
                  .ft610{font-size:10px;line-height:14px;font-family:Times;color:#000000;}
                  .ft611{font-size:8px;line-height:12px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page6-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target006.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:36px;left:54px;white-space:nowrap" class="ft60">&#160; &#160; &#160;</p>
               <p style="position:absolute;top:56px;left:236px;white-space:nowrap" class="ft61"><b>a &#160;</b>Employee’s social security number<br> <span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['social_security_number']; ?></span></p>
               <p style="position:absolute;top:72px;left:430px;white-space:nowrap" class="ft61"><b>&#160;</b>OMB No. 1545-0008&#160;</p>
               <p style="position:absolute;top:55px;left:540px;white-space:nowrap" class="ft62">This information is being furnished to the Internal Revenue Service. If you&#160;</p>
               <p style="position:absolute;top:66px;left:540px;white-space:nowrap" class="ft62">are required to file a tax return, a negligence penalty or other sanction&#160;</p>
               <p style="position:absolute;top:76px;left:540px;white-space:nowrap" class="ft62">may be imposed on you if this income is taxable and you fail to report it.</p>
               <p style="position:absolute;top:92px;left:63px;white-space:nowrap" class="ft61"><b>b &#160;</b>Employer identification number (EIN) <br> <span style="color: #000; font-size: 14px;"><?php echo htmlspecialchars($c_details[0]['Federal_Pin_Number'], ENT_QUOTES, 'UTF-8'); ?></span></p>
               <p style="position:absolute;top:128px;left:63px;white-space:nowrap" class="ft61"><b>c &#160;</b>Employer’s name, address, and ZIP code <br><span style="color: #000; font-size: 14px;"><?php echo $getlocation[0]['address']; ?></span></p>
               <p style="position:absolute;top:236px;left:63px;white-space:nowrap" class="ft61"><b>d &#160;</b>Control number</p>
               <p style="position:absolute;top:272px;left:63px;white-space:nowrap" class="ft61"><b>e &#160;</b>Employee’s first name and initial <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['first_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:265px;white-space:nowrap" class="ft62">Last name <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['last_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:470px;white-space:nowrap" class="ft62">Suff.</p>
               <p style="position:absolute;top:416px;left:63px;white-space:nowrap" class="ft61"><b>f &#160;</b>Employee’s address and ZIP code <br><span style="color: #000; font-size: 14px; position: absolute; bottom: 18px;"><?php echo $e_details[0]['address_line_1']; ?> </span></p>
               <p style="position:absolute;top:92px;left:508px;white-space:nowrap" class="ft61"><b>1 &#160;&#160;</b>Wages, tips, other compensation 
                  <br><span style="color: #000; font-size: 14px;"> 
                  $<?php echo htmlspecialchars($t_tax, ENT_QUOTES, 'UTF-8'); ?> 
                  </span>
               </p>
               <p style="position:absolute;top:92px;left:692px;white-space:nowrap" class="ft61"><b>2 &#160;&#160;</b>Federal income tax withheld<br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:128px;left:508px;white-space:nowrap" class="ft61"><b>3 &#160;&#160;</b>Social security wages<br><span style="color: #000; font-size: 14px;"><?php 
                  $S_tax = 0; 
                  $S_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo  '$'  .$S_tax;
                  ?></span></p>
               <p style="position:absolute;top:128px;left:692px;white-space:nowrap" class="ft61"><b>4 &#160;&#160;</b>Social security tax withheld<br>
                  <span style="color: #000; font-size: 14px;">
                  $<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:164px;left:508px;white-space:nowrap" class="ft61"><b>5 &#160;&#160;</b>Medicare wages and tips<br><span style="color: #000; font-size: 14px;"><?php 
                  $S_tax = 0; 
                  $S_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo  '$'  .$S_tax;
                  ?></span></p>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft61"><b>6 &#160;&#160;</b>Medicare tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>
               <p style="position:absolute;top:200px;left:508px;white-space:nowrap" class="ft61"><b>7 &#160;&#160;</b>Social security tips</p>
               <p style="position:absolute;top:200px;left:692px;white-space:nowrap" class="ft61"><b>8 &#160;&#160;</b>Allocated tips</p>
               <p style="position:absolute;top:236px;left:508px;white-space:nowrap" class="ft61"><b>9 &#160;&#160;</b></p>
               <p style="position:absolute;top:236px;left:686px;white-space:nowrap" class="ft61"><b>10 &#160;&#160;</b>Dependent care benefits</p>
               <p style="position:absolute;top:272px;left:503px;white-space:nowrap" class="ft61"><b>11 &#160;&#160;</b>Nonqualified plans</p>
               <p style="position:absolute;top:272px;left:686px;white-space:nowrap" class="ft61"><b>12a&#160;</b>See instructions for box 12</p>
               <p style="position:absolute;top:282px;left:687px;white-space:nowrap" class="ft63">C</p>
               <p style="position:absolute;top:287px;left:687px;white-space:nowrap" class="ft63">o&#160;</p>
               <p style="position:absolute;top:293px;left:687px;white-space:nowrap" class="ft63">d&#160;</p>
               <p style="position:absolute;top:298px;left:688px;white-space:nowrap" class="ft63">e</p>
               <p style="position:absolute;top:308px;left:686px;white-space:nowrap" class="ft61"><b>12b</b></p>
               <p style="position:absolute;top:318px;left:687px;white-space:nowrap" class="ft63">C</p>
               <p style="position:absolute;top:323px;left:687px;white-space:nowrap" class="ft63">o&#160;</p>
               <p style="position:absolute;top:329px;left:687px;white-space:nowrap" class="ft63">d&#160;</p>
               <p style="position:absolute;top:334px;left:688px;white-space:nowrap" class="ft63">e</p>
               <p style="position:absolute;top:344px;left:686px;white-space:nowrap" class="ft61"><b>12c</b></p>
               <p style="position:absolute;top:354px;left:687px;white-space:nowrap" class="ft63">C</p>
               <p style="position:absolute;top:359px;left:687px;white-space:nowrap" class="ft63">o&#160;</p>
               <p style="position:absolute;top:365px;left:687px;white-space:nowrap" class="ft63">d&#160;</p>
               <p style="position:absolute;top:370px;left:688px;white-space:nowrap" class="ft63">e</p>
               <p style="position:absolute;top:380px;left:686px;white-space:nowrap" class="ft61"><b>12d</b></p>
               <p style="position:absolute;top:390px;left:687px;white-space:nowrap" class="ft63">C</p>
               <p style="position:absolute;top:395px;left:687px;white-space:nowrap" class="ft63">o&#160;</p>
               <p style="position:absolute;top:401px;left:687px;white-space:nowrap" class="ft63">d&#160;</p>
               <p style="position:absolute;top:406px;left:688px;white-space:nowrap" class="ft63">e</p>
               <p style="position:absolute;top:308px;left:503px;white-space:nowrap" class="ft61"><b>13</b></p>
               <p style="position:absolute;top:307px;left:523px;white-space:nowrap" class="ft64">Statutory&#160;</p>
               <p style="position:absolute;top:315px;left:523px;white-space:nowrap" class="ft64">employee</p>
               <p style="position:absolute;top:307px;left:577px;white-space:nowrap" class="ft64">Retirement&#160;</p>
               <p style="position:absolute;top:315px;left:577px;white-space:nowrap" class="ft64">plan</p>
               <p style="position:absolute;top:307px;left:631px;white-space:nowrap" class="ft64">Third-party&#160;</p>
               <p style="position:absolute;top:315px;left:631px;white-space:nowrap" class="ft64">sick pay</p>
               
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap ;" class="ft32"><b>14 &#160;</b>Other
               <br>
               <span style="color: black;font-size: 8px !important;font-size: 9px; top: 12px; left: -60px; ">
                  <?php foreach ($gettaxother_info as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4);?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($other_tx as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4); ?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($countyTax as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4); ?>    <br>
                  </span>
                  <?php  endforeach; ?>
                  </span>
               </p>
               <?php
                  $matchedCode = '';
                  $matchedTaxType = '';
                  
                  $matchedCode1 = '';
                  $matchedTaxType1 = '';
                  
                  $matchedCode2 = '';
                  $matchedTaxType2 = '';
                  
                  
                  $matchedCode3 = '';
                  $matchedTaxType3 = '';
                  
                  foreach ($StatetaxType as $data) {
                      if ($data['tax_type'] === 'state_tax') {
                          $matchedCode = $data['code'];
                          $matchedTaxType = $data['tax_type'];
                          break;
                      }
                  }
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                      if ($datas['tax_type'] === 'living_state_tax') {
                          $matchedCode1 = $datas['code'];
                          $matchedTaxType1 = $datas['tax_type'];
                          break;
                      }
                  }
                  
                  
                   
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'living_local_tax') {
                      $matchedCode2 = $datas['code'];
                      $matchedTaxType2 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'local_tax') {
                      $matchedCode3 = $datas['code'];
                      $matchedTaxType3 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                    
                  ?>
               <p style="position:absolute;top:434px;left:57px;white-space:nowrap" class="ft61"><b>15 &#160;</b>State&#160;Employer’s state ID number
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative;">
                  <?php echo htmlspecialchars($matchedCode, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px;"><?php echo !empty($matchedCode) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?>  </span>
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative; top: 15px;">
                  <?php echo htmlspecialchars($matchedCode1, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px; top: 15px;"><?php echo !empty($matchedCode1) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?>  </span> 
               </p>
               <p style="position:absolute;top:434px;left:296px;white-space:nowrap" class="ft61"><b>16 &#160;</b>State wages, tips, etc 
                  <br><span style="color: #000; font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>   
               </p>
               <?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }

                 ?>
               <?php
                  $overalltotal_statetaxworking = isset($stateworkingtax[0]['overalltotal_statetaxworking']) ? number_format($stateworkingtax[0]['overalltotal_statetaxworking'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:427px;white-space:nowrap" class="ft61"><b>17 &#160;</b>State income tax 
                 <br> <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $overalltotal_statetax, ENT_QUOTES, 'UTF-8') : ''; ?>   
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $overalltotal_statetaxworking, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:545px;white-space:nowrap" class="ft61"><b>18 &#160;</b>Local wages, tips, etc
                  <br>
                  <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span> 
               </p>
               <?php
                  $overalltotal_localtax = isset($localTax[0]['overalltotal_localtax']) ? number_format($localTax[0]['overalltotal_localtax'], 2) : '0';
                  ?>
               <?php
                  $livinglocaltax = isset($livinglocaldata[0]['livinglocaltax']) ? number_format($livinglocaldata[0]['livinglocaltax'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:674px;white-space:nowrap" class="ft61"><b>19 &#160;</b>Local income tax <br>
                  <span style="color: black;font-size: large;font-size: 14px; position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $overalltotal_localtax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $livinglocaltax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:793px;white-space:nowrap" class="ft61"><b>20 &#160;</b>Locality name
               <br>
                  <span style="color: black;font-size: large;font-size: 14px; position: relative;left: 37px;"> 
                  <?php echo htmlspecialchars($matchedCode3, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
                  <br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;top: 9px;left: 37px; "> 
                  <?php echo htmlspecialchars($matchedCode2, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
               </p>
               <p style="position:absolute;top:528px;left:54px;white-space:nowrap" class="ft61"><b>Form</b></p>
               <p style="position:absolute;top:504px;left:86px;white-space:nowrap" class="ft65"><b>W-2</b></p>
               <p style="position:absolute;top:516px;left:160px;white-space:nowrap" class="ft66">Wage and Tax Statement</p>
               <p style="position:absolute;top:509px;left:434px;white-space:nowrap" class="ft67"><?php echo date('Y'); ?></p>
               <p style="position:absolute;top:513px;left:608px;white-space:nowrap" class="ft62">Department of the Treasury—Internal Revenue Service</p>
               <p style="position:absolute;top:545px;left:54px;white-space:nowrap" class="ft610"><b>Copy C—For EMPLOYEE’S RECORDS&#160;<br/></b>(See&#160;<i>Notice to Employee&#160;</i>on the back of Copy B.)</p>
               <p style="position:absolute;top:531px;left:660px;white-space:nowrap" class="ft611"><b>Safe, accurate,&#160;<br/>FAST! &#160;Use</b></p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft70{font-size:16px;font-family:Times;color:#000000;}
                  .ft71{font-size:10px;font-family:Times;color:#000000;}
                  .ft72{font-size:10px;font-family:Times;color:#000000;}
                  .ft73{font-size:10px;font-family:Times;color:#000000;}
                  .ft74{font-size:10px;line-height:17px;font-family:Times;color:#000000;}
                  .ft75{font-size:10px;line-height:17px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page7-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target007.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:49px;left:54px;white-space:nowrap" class="ft70"><b>Instructions for Employee</b></p>
               <p style="position:absolute;top:75px;left:54px;white-space:nowrap" class="ft71">(See also&#160;<i>Notice to</i></p>
               <p style="position:absolute;top:75px;left:155px;white-space:nowrap" class="ft73"><b>&#160;</b><i>Employee&#160;</i>on the back of Copy B.)</p>
               <p style="position:absolute;top:92px;left:54px;white-space:nowrap" class="ft74"><b>Box 1.&#160;</b>Enter this amount on the wages line of your tax return.<b>&#160;<br/>Box 2.&#160;</b>Enter this amount on the federal income tax withheld<b>&#160;</b>line of your&#160;</p>
               <p style="position:absolute;top:124px;left:54px;white-space:nowrap" class="ft75">tax return.<br/><b>Box 5.&#160;</b>You may be required to report this amount on Form 8959. See&#160;</p>
               <p style="position:absolute;top:154px;left:54px;white-space:nowrap" class="ft71">the Form 1040 instructions to determine if you are required to complete&#160;</p>
               <p style="position:absolute;top:167px;left:54px;white-space:nowrap" class="ft75">Form 8959.<br/><b>Box 6.&#160;</b>This amount includes the 1.45% Medicare tax withheld on all&#160;</p>
               <p style="position:absolute;top:198px;left:54px;white-space:nowrap" class="ft71">Medicare wages and tips shown in box 5, as well as the 0.9% Additional&#160;</p>
               <p style="position:absolute;top:211px;left:54px;white-space:nowrap" class="ft71">Medicare Tax on any of those Medicare wages and tips above&#160;</p>
               <p style="position:absolute;top:224px;left:54px;white-space:nowrap" class="ft75">$200,000.<br/><b>Box 8.&#160;</b>This amount is&#160;<b>not&#160;</b>included in box 1, 3, 5, or 7. For<b>&#160;</b>information&#160;</p>
               <p style="position:absolute;top:255px;left:54px;white-space:nowrap" class="ft71">on how to report tips on your tax return, see the Form 1040 instructions.</p>
               <p style="position:absolute;top:273px;left:66px;white-space:nowrap" class="ft71">You must file Form 4137 with your income tax return to report at least&#160;</p>
               <p style="position:absolute;top:286px;left:54px;white-space:nowrap" class="ft71">the allocated tip amount unless you can prove with adequate records&#160;</p>
               <p style="position:absolute;top:299px;left:54px;white-space:nowrap" class="ft71">that you received a smaller amount. If you have records that show the&#160;</p>
               <p style="position:absolute;top:312px;left:54px;white-space:nowrap" class="ft71">actual amount of tips you received, report that amount even if it is more&#160;</p>
               <p style="position:absolute;top:325px;left:54px;white-space:nowrap" class="ft71">or less than the allocated tips. Use Form 4137 to figure the social&#160;</p>
               <p style="position:absolute;top:338px;left:54px;white-space:nowrap" class="ft71">security and Medicare tax owed on tips you didn’t report to your&#160;</p>
               <p style="position:absolute;top:352px;left:54px;white-space:nowrap" class="ft71">employer. Enter this amount on the wages line of your tax return. By&#160;</p>
               <p style="position:absolute;top:365px;left:54px;white-space:nowrap" class="ft71">filing Form 4137, your social security tips will be credited to your social&#160;</p>
               <p style="position:absolute;top:378px;left:54px;white-space:nowrap" class="ft75">security record (used to figure your benefits).<br/><b>Box 10.&#160;</b>This amount includes the total dependent care benefits that<b>&#160;</b></p>
               <p style="position:absolute;top:409px;left:54px;white-space:nowrap" class="ft71">your employer paid to you or incurred on your behalf (including</p>
               <p style="position:absolute;top:408px;left:391px;white-space:nowrap" class="ft73"><b>&#160;</b>amounts&#160;</p>
               <p style="position:absolute;top:422px;left:54px;white-space:nowrap" class="ft71">from a section 125 (cafeteria) plan). Any amount over</p>
               <p style="position:absolute;top:421px;left:337px;white-space:nowrap" class="ft73"><b>&#160;</b>your employer’s&#160;</p>
               <p style="position:absolute;top:435px;left:54px;white-space:nowrap" class="ft75">plan limit is also included in box 1. See Form 2441.<br/><b>Box 11.&#160;</b>This amount is (a) reported in box 1 if it is a distribution<b>&#160;</b>made to&#160;</p>
               <p style="position:absolute;top:466px;left:54px;white-space:nowrap" class="ft71">you from a nonqualified deferred compensation or nongovernmental&#160;</p>
               <p style="position:absolute;top:479px;left:54px;white-space:nowrap" class="ft71">section 457(b) plan, or (b) included in box 3 and/or box 5 if it is a prior&#160;</p>
               <p style="position:absolute;top:492px;left:54px;white-space:nowrap" class="ft71">year deferral under a nonqualified or section 457(b) plan that became&#160;</p>
               <p style="position:absolute;top:505px;left:54px;white-space:nowrap" class="ft71">taxable for social security and Medicare taxes this year because there is&#160;</p>
               <p style="position:absolute;top:518px;left:54px;white-space:nowrap" class="ft71">no longer a substantial risk of forfeiture of your right to the deferred&#160;</p>
               <p style="position:absolute;top:531px;left:54px;white-space:nowrap" class="ft71">amount. This box shouldn’t be used if you had a deferral and a&#160;</p>
               <p style="position:absolute;top:544px;left:54px;white-space:nowrap" class="ft71">distribution in the same calendar year. If you made a deferral and</p>
               <p style="position:absolute;top:51px;left:475px;white-space:nowrap" class="ft71">received a distribution in the same calendar year, and you are or will be&#160;</p>
               <p style="position:absolute;top:64px;left:475px;white-space:nowrap" class="ft71">age 62 by the end of the calendar year, your employer should file Form&#160;</p>
               <p style="position:absolute;top:77px;left:475px;white-space:nowrap" class="ft71">SSA-131, Employer Report of Special Wage Payments, with the Social&#160;</p>
               <p style="position:absolute;top:91px;left:475px;white-space:nowrap" class="ft75">Security Administration and give you a copy.<br/><b>Box 12.&#160;</b>The following list explains the codes shown in box 12. You may&#160;</p>
               <p style="position:absolute;top:121px;left:475px;white-space:nowrap" class="ft71">need this information to complete your tax</p>
               <p style="position:absolute;top:121px;left:702px;white-space:nowrap" class="ft73"><b>&#160;</b>return. Elective deferrals&#160;</p>
               <p style="position:absolute;top:135px;left:475px;white-space:nowrap" class="ft71">(codes D, E, F, and S) and designated</p>
               <p style="position:absolute;top:134px;left:678px;white-space:nowrap" class="ft73"><b>&#160;</b>Roth contributions (codes AA,&#160;</p>
               <p style="position:absolute;top:148px;left:475px;white-space:nowrap" class="ft71">BB, and EE) under all plans are generally limited to a total of $23,000&#160;</p>
               <p style="position:absolute;top:161px;left:475px;white-space:nowrap" class="ft71">($16,000 if you only have SIMPLE plans; $26,000 for section 403(b)&#160;</p>
               <p style="position:absolute;top:174px;left:475px;white-space:nowrap" class="ft71">plans if you qualify for the 15-year rule explained in Pub. 571). Deferrals&#160;</p>
               <p style="position:absolute;top:187px;left:475px;white-space:nowrap" class="ft71">under code G are limited to $23,000. Deferrals under code H are limited&#160;</p>
               <p style="position:absolute;top:200px;left:475px;white-space:nowrap" class="ft71">to $7,000.</p>
               <p style="position:absolute;top:218px;left:487px;white-space:nowrap" class="ft71">However, if you were at least age 50 in 2024, your employer may have&#160;</p>
               <p style="position:absolute;top:231px;left:475px;white-space:nowrap" class="ft71">allowed an additional deferral of up to $7,500 ($3,500 for section &#160;</p>
               <p style="position:absolute;top:244px;left:475px;white-space:nowrap" class="ft71">401(k)(11) and 408(p) SIMPLE plans). This additional deferral amount is&#160;</p>
               <p style="position:absolute;top:257px;left:475px;white-space:nowrap" class="ft71">not subject to the overall limit on elective deferrals. For code G, the limit&#160;</p>
               <p style="position:absolute;top:270px;left:475px;white-space:nowrap" class="ft71">on elective deferrals may be higher for the last 3 years before you reach&#160;</p>
               <p style="position:absolute;top:283px;left:475px;white-space:nowrap" class="ft71">retirement age. Contact your plan administrator for more information.&#160;</p>
               <p style="position:absolute;top:297px;left:475px;white-space:nowrap" class="ft71">Amounts in excess of the overall elective deferral limit must be included&#160;</p>
               <p style="position:absolute;top:310px;left:475px;white-space:nowrap" class="ft75">in income. See the Form 1040 instructions.<br/><b>Note:&#160;</b>If a year follows code D through H, S, Y, AA, BB, or EE, you<b>&#160;</b>made&#160;</p>
               <p style="position:absolute;top:340px;left:475px;white-space:nowrap" class="ft71">a make-up pension contribution for a prior year(s) when</p>
               <p style="position:absolute;top:340px;left:772px;white-space:nowrap" class="ft73"><b>&#160;</b>you were in&#160;</p>
               <p style="position:absolute;top:354px;left:475px;white-space:nowrap" class="ft71">military service. To figure whether you made excess</p>
               <p style="position:absolute;top:353px;left:753px;white-space:nowrap" class="ft73"><b>&#160;</b>deferrals, consider&#160;</p>
               <p style="position:absolute;top:367px;left:475px;white-space:nowrap" class="ft71">these amounts for the year shown, not the</p>
               <p style="position:absolute;top:366px;left:702px;white-space:nowrap" class="ft73"><b>&#160;</b>current year. If no year is&#160;</p>
               <p style="position:absolute;top:380px;left:475px;white-space:nowrap" class="ft71">shown, the contributions are for the</p>
               <p style="position:absolute;top:380px;left:666px;white-space:nowrap" class="ft73"><b>&#160;</b>current year.</p>
               <p style="position:absolute;top:397px;left:475px;white-space:nowrap" class="ft73"><b>A—</b>Uncollected social security or RRTA tax on tips. Include this<b>&#160;</b>tax on&#160;</p>
               <p style="position:absolute;top:411px;left:475px;white-space:nowrap" class="ft75">Form 1040 or 1040-SR. See the Form 1040 instructions.<br/><b>B—</b>Uncollected Medicare tax on tips. Include this tax on Form<b>&#160;</b>1040 or&#160;</p>
               <p style="position:absolute;top:441px;left:475px;white-space:nowrap" class="ft75">1040-SR. See the Form 1040 instructions.<br/><b>C—</b>Taxable cost of group-term life insurance over $50,000<b>&#160;</b>(included in&#160;</p>
               <p style="position:absolute;top:472px;left:475px;white-space:nowrap" class="ft75">boxes 1, 3 (up to the social security wage base), and 5)<br/><b>D—</b>Elective deferrals to a section 401(k) cash or deferred<b>&#160;</b>arrangement.&#160;</p>
               <p style="position:absolute;top:503px;left:475px;white-space:nowrap" class="ft71">Also includes deferrals under a SIMPLE retirement</p>
               <p style="position:absolute;top:503px;left:745px;white-space:nowrap" class="ft73"><b>&#160;</b>account that is part&#160;</p>
               <p style="position:absolute;top:516px;left:475px;white-space:nowrap" class="ft75">of a section 401(k) arrangement.<br/><b>E—</b>Elective deferrals under a section 403(b) salary reduction<b>&#160;</b>agreement</p>
               <p style="position:absolute;top:551px;left:703px;white-space:nowrap" class="ft72"><i>(continued on back of Copy 2)</i></p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft80{font-size:10px;font-family:Times;color:#000000;}
                  .ft81{font-size:8px;font-family:Times;color:#000000;}
                  .ft82{font-size:8px;font-family:Times;color:#000000;}
                  .ft83{font-size:4px;font-family:Times;color:#000000;}
                  .ft84{font-size:5px;font-family:Times;color:#000000;}
                  .ft85{font-size:34px;font-family:Times;color:#000000;}
                  .ft86{font-size:14px;font-family:Times;color:#000000;}
                  .ft87{font-size:34px;font-family:Times;color:#000000;}
                  .ft88{font-size:10px;font-family:Times;color:#000000;}
                  .ft89{font-size:10px;line-height:14px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page8-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target008.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:36px;left:54px;white-space:nowrap" class="ft80">&#160; &#160; &#160;</p>
               <p style="position:absolute;top:56px;left:236px;white-space:nowrap" class="ft81"><b>a &#160;</b>Employee’s social security number<br> <span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['social_security_number']; ?></span></p>
               <p style="position:absolute;top:72px;left:430px;white-space:nowrap" class="ft81"><b>&#160;</b>OMB No. 1545-0008&#160;</p>
               <p style="position:absolute;top:92px;left:63px;white-space:nowrap" class="ft81"><b>b &#160;</b>Employer identification number (EIN) <br> <span style="color: #000; font-size: 14px;"><?php echo htmlspecialchars($c_details[0]['Federal_Pin_Number'], ENT_QUOTES, 'UTF-8'); ?></span></p>
               <p style="position:absolute;top:128px;left:63px;white-space:nowrap" class="ft81"><b>c &#160;</b>Employer’s name, address, and ZIP code <br><span style="color: #000; font-size: 14px;"><?php echo $getlocation[0]['address']; ?></span></p>
               <p style="position:absolute;top:236px;left:63px;white-space:nowrap" class="ft81"><b>d &#160;</b>Control number</p>
               <p style="position:absolute;top:272px;left:63px;white-space:nowrap" class="ft81"><b>e &#160;</b>Employee’s first name and initial <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['first_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:265px;white-space:nowrap" class="ft82">Last name <br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['last_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:470px;white-space:nowrap" class="ft82">Suff.</p>
               <p style="position:absolute;top:416px;left:63px;white-space:nowrap" class="ft81"><b>f &#160;</b>Employee’s address and ZIP code  <br><span style="color: #000; font-size: 14px; position: absolute; bottom: 18px;"><?php echo $e_details[0]['address_line_1']; ?> </span></p>
               <p style="position:absolute;top:92px;left:508px;white-space:nowrap" class="ft81"><b>1 &#160;&#160;</b>Wages, tips, other compensation 
                  <br><span style="color: #000; font-size: 14px;"> 
                  $<?php echo htmlspecialchars($t_tax, ENT_QUOTES, 'UTF-8'); ?> 
                  </span>
               </p>
               <p style="position:absolute;top:92px;left:692px;white-space:nowrap" class="ft81"><b>2 &#160;&#160;</b>Federal income tax withheld<br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:128px;left:508px;white-space:nowrap" class="ft81"><b>3 &#160;&#160;</b>Social security wages<br><span style="color: #000; font-size: 14px;"><?php 
                  $S_tax = 0; 
                  $S_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$'.$S_tax;
                  ?></span></p>
               <p style="position:absolute;top:128px;left:692px;white-space:nowrap" class="ft81"><b>4 &#160;&#160;</b>Social security tax withheld <br>
                  <span style="color: #000; font-size: 14px;">
                  $<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:164px;left:508px;white-space:nowrap" class="ft81"><b>5 &#160;&#160;</b>Medicare wages and tips <br><span style="color: #000; font-size: 14px;"><?php 
                  $t_tax = 0; 
                  $t_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$'. $t_tax;
                  ?></span></p>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft61"><b>6 &#160;&#160;</b>Medicare tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>
               <p style="position:absolute;top:200px;left:508px;white-space:nowrap" class="ft81"><b>7 &#160;&#160;</b>Social security tips</p>
               <p style="position:absolute;top:200px;left:692px;white-space:nowrap" class="ft81"><b>8 &#160;&#160;</b>Allocated tips</p>
               <p style="position:absolute;top:236px;left:508px;white-space:nowrap" class="ft81"><b>9 &#160;&#160;</b></p>
               <p style="position:absolute;top:236px;left:686px;white-space:nowrap" class="ft81"><b>10 &#160;&#160;</b>Dependent care benefits</p>
               <p style="position:absolute;top:272px;left:503px;white-space:nowrap" class="ft81"><b>11 &#160;&#160;</b>Nonqualified plans</p>
               <p style="position:absolute;top:272px;left:686px;white-space:nowrap" class="ft81"><b>12a &#160;</b></p>
               <p style="position:absolute;top:282px;left:687px;white-space:nowrap" class="ft83">C</p>
               <p style="position:absolute;top:287px;left:687px;white-space:nowrap" class="ft83">o&#160;</p>
               <p style="position:absolute;top:293px;left:687px;white-space:nowrap" class="ft83">d&#160;</p>
               <p style="position:absolute;top:298px;left:688px;white-space:nowrap" class="ft83">e</p>
               <p style="position:absolute;top:308px;left:686px;white-space:nowrap" class="ft81"><b>12b</b></p>
               <p style="position:absolute;top:318px;left:687px;white-space:nowrap" class="ft83">C</p>
               <p style="position:absolute;top:323px;left:687px;white-space:nowrap" class="ft83">o&#160;</p>
               <p style="position:absolute;top:329px;left:687px;white-space:nowrap" class="ft83">d&#160;</p>
               <p style="position:absolute;top:334px;left:688px;white-space:nowrap" class="ft83">e</p>
               <p style="position:absolute;top:344px;left:686px;white-space:nowrap" class="ft81"><b>12c</b></p>
               <p style="position:absolute;top:354px;left:687px;white-space:nowrap" class="ft83">C</p>
               <p style="position:absolute;top:359px;left:687px;white-space:nowrap" class="ft83">o&#160;</p>
               <p style="position:absolute;top:365px;left:687px;white-space:nowrap" class="ft83">d&#160;</p>
               <p style="position:absolute;top:370px;left:688px;white-space:nowrap" class="ft83">e</p>
               <p style="position:absolute;top:380px;left:686px;white-space:nowrap" class="ft81"><b>12d</b></p>
               <p style="position:absolute;top:390px;left:687px;white-space:nowrap" class="ft83">C</p>
               <p style="position:absolute;top:395px;left:687px;white-space:nowrap" class="ft83">o&#160;</p>
               <p style="position:absolute;top:401px;left:687px;white-space:nowrap" class="ft83">d&#160;</p>
               <p style="position:absolute;top:406px;left:688px;white-space:nowrap" class="ft83">e</p>
               <p style="position:absolute;top:308px;left:503px;white-space:nowrap" class="ft81"><b>13</b></p>
               <p style="position:absolute;top:307px;left:523px;white-space:nowrap" class="ft84">Statutory&#160;</p>
               <p style="position:absolute;top:315px;left:523px;white-space:nowrap" class="ft84">employee</p>
               <p style="position:absolute;top:307px;left:577px;white-space:nowrap" class="ft84">Retirement&#160;</p>
               <p style="position:absolute;top:315px;left:577px;white-space:nowrap" class="ft84">plan</p>
               <p style="position:absolute;top:307px;left:631px;white-space:nowrap" class="ft84">Third-party&#160;</p>
               <p style="position:absolute;top:315px;left:631px;white-space:nowrap" class="ft84">sick pay</p>
              
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap ;" class="ft32"><b>14 &#160;</b>Other
                <br>
                <span style="color: black;font-size: 8px !important;font-size: 9px; top: 12px; left: -60px; ">
                  <?php foreach ($gettaxother_info as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4);?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($other_tx as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4); ?>    <br>
                  </span>
                  <?php  endforeach; ?>

                  <?php foreach ($countyTax as $tax_info) : ?>
                  <span>
                  <?php echo ($tax_info['tax']); ?>  -  <?php echo number_format($tax_info['amount'], 4); ?>    <br>
                  </span>
                  <?php  endforeach; ?>
                  </span>
               </p>
               <?php
                  $matchedCode = '';
                  $matchedTaxType = '';
                  
                  $matchedCode1 = '';
                  $matchedTaxType1 = '';
                  
                  $matchedCode2 = '';
                  $matchedTaxType2 = '';
                  
                  
                  $matchedCode3 = '';
                  $matchedTaxType3 = '';
                  
                  foreach ($StatetaxType as $data) {
                      if ($data['tax_type'] === 'state_tax') {
                          $matchedCode = $data['code'];
                          $matchedTaxType = $data['tax_type'];
                          break;
                      }
                  }
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                      if ($datas['tax_type'] === 'living_state_tax') {
                          $matchedCode1 = $datas['code'];
                          $matchedTaxType1 = $datas['tax_type'];
                          break;
                      }
                  }
                  
                  
                   
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'living_local_tax') {
                      $matchedCode2 = $datas['code'];
                      $matchedTaxType2 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'local_tax') {
                      $matchedCode3 = $datas['code'];
                      $matchedTaxType3 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                    
                  ?>
               <p style="position:absolute;top:434px;left:57px;white-space:nowrap" class="ft81"><b>15 &#160;</b>State&#160;Employer’s state ID number
                   <br>  
                  <span style="color: #000; font-size: 14px; position: relative;">
                  <?php echo htmlspecialchars($matchedCode, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px;"><?php echo !empty($matchedCode) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative; top: 15px;">
                  <?php echo htmlspecialchars($matchedCode1, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px; top: 15px;"><?php echo !empty($matchedCode1) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
               </p>
               <p style="position:absolute;top:434px;left:296px;white-space:nowrap" class="ft81"><b>16 &#160;</b>State wages, tips, etc 
                  <br><span style="color: #000; font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>   
               </p>

               /* //ajith */


               <?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }

                 ?>




            
               <?php
                  $overalltotal_statetaxworking = isset($stateworkingtax[0]['overalltotal_statetaxworking']) ? number_format($stateworkingtax[0]['overalltotal_statetaxworking'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:427px;white-space:nowrap" class="ft81"><b>17 &#160;</b>State income tax 
                  <br> <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $overalltotal_statetax, ENT_QUOTES, 'UTF-8') : ''; ?>   
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $overalltotal_statetaxworking, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:545px;white-space:nowrap" class="ft81"><b>18 &#160;</b>Local wages, tips, etc
                  <br>
                  <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>   
                  </span> 
               </p>
               <?php
                  $overalltotal_localtax = isset($localTax[0]['overalltotal_localtax']) ? number_format($localTax[0]['overalltotal_localtax'], 2) : '0';
                  ?>
               <?php
                  $livinglocaltax = isset($livinglocaldata[0]['livinglocaltax']) ? number_format($livinglocaldata[0]['livinglocaltax'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:674px;white-space:nowrap" class="ft81"><b>19 &#160;</b>Local income tax <br> 
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $overalltotal_localtax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $livinglocaltax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>  
               </p>
               <p style="position:absolute;top:434px;left:793px;white-space:nowrap" class="ft81"><b>20 &#160;</b>Locality name<br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo htmlspecialchars($matchedCode3, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
                  <br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;top: 9px;left: 37px; "> 
                  <?php echo htmlspecialchars($matchedCode2, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
               </p>
               <p style="position:absolute;top:528px;left:54px;white-space:nowrap" class="ft81"><b>Form</b></p>
               <p style="position:absolute;top:504px;left:86px;white-space:nowrap" class="ft85"><b>W-2</b></p>
               <p style="position:absolute;top:516px;left:160px;white-space:nowrap" class="ft86">Wage and Tax Statement</p>
               <p style="position:absolute;top:509px;left:434px;white-space:nowrap" class="ft87"><?php echo date('Y'); ?></p>
               <p style="position:absolute;top:513px;left:608px;white-space:nowrap" class="ft82">Department of the Treasury—Internal Revenue Service</p>
               <p style="position:absolute;top:545px;left:54px;white-space:nowrap" class="ft89"><b>Copy 2—To Be Filed With Employee’s State, City, or Local&#160;<br/>Income Tax Return</b></p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft90{font-size:16px;font-family:Times;color:#000000;}
                  .ft91{font-size:10px;font-family:Times;color:#000000;}
                  .ft92{font-size:10px;font-family:Times;color:#000000;}
                  .ft93{font-size:8px;font-family:Times;color:#000000;}
                  .ft94{font-size:8px;font-family:Times;color:#000000;}
                  .ft95{font-size:10px;font-family:Times;color:#000000;}
                  .ft96{font-size:10px;line-height:17px;font-family:Times;color:#000000;}
                  .ft97{font-size:10px;line-height:17px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page9-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target009.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:49px;left:54px;white-space:nowrap" class="ft90"><b>Instructions for Employee</b></p>
               <p style="position:absolute;top:55px;left:275px;white-space:nowrap" class="ft91"><b>&#160;</b><i>(continued from back of</i><b>&#160;</b><i>Copy C)</i></p>
               <p style="position:absolute;top:75px;left:54px;white-space:nowrap" class="ft93"><b>Box 12</b><i>&#160;(continued)</i></p>
               <p style="position:absolute;top:90px;left:54px;white-space:nowrap" class="ft96"><b>F—</b>Elective deferrals under a section 408(k)(6) salary<b>&#160;</b>reduction SEP<br/><b>G—</b>Elective deferrals and employer contributions (including<b>&#160;</b>nonelective&#160;</p>
               <p style="position:absolute;top:121px;left:54px;white-space:nowrap" class="ft95">deferrals) to a section 457(b) deferred</p>
               <p style="position:absolute;top:121px;left:255px;white-space:nowrap" class="ft91"><b>&#160;</b>compensation plan</p>
               <p style="position:absolute;top:139px;left:54px;white-space:nowrap" class="ft91"><b>H—</b>Elective deferrals to a section 501(c)(18)(D) tax-exempt<b>&#160;</b>organization&#160;</p>
               <p style="position:absolute;top:152px;left:54px;white-space:nowrap" class="ft95">plan. See the Form</p>
               <p style="position:absolute;top:152px;left:156px;white-space:nowrap" class="ft91"><b>&#160;</b>1040 instructions for how to deduct.</p>
               <p style="position:absolute;top:169px;left:54px;white-space:nowrap" class="ft96"><b>J—</b>Nontaxable sick pay (information only, not included in<b>&#160;</b>box 1, 3, or 5)<br/><b>K—</b>20% excise tax on excess golden parachute payments.<b>&#160;</b>See the&#160;</p>
               <p style="position:absolute;top:200px;left:54px;white-space:nowrap" class="ft95">Form</p>
               <p style="position:absolute;top:200px;left:82px;white-space:nowrap" class="ft91"><b>&#160;</b>1040 instructions.</p>
               <p style="position:absolute;top:218px;left:54px;white-space:nowrap" class="ft91"><b>L—</b>Substantiated employee business expense<b>&#160;</b>reimbursements&#160;</p>
               <p style="position:absolute;top:231px;left:54px;white-space:nowrap" class="ft96">(nontaxable)<br/><b>M—</b>Uncollected social security or RRTA tax on taxable cost<b>&#160;</b>of group-</p>
               <p style="position:absolute;top:262px;left:54px;white-space:nowrap" class="ft95">term life insurance over $50,000 (former employees</p>
               <p style="position:absolute;top:262px;left:329px;white-space:nowrap" class="ft91"><b>&#160;</b>only). See the Form<b>&#160;</b></p>
               <p style="position:absolute;top:275px;left:54px;white-space:nowrap" class="ft96">1040 instructions.<br/><b>N—</b>Uncollected Medicare tax on taxable cost of group-term<b>&#160;</b>life&#160;</p>
               <p style="position:absolute;top:306px;left:54px;white-space:nowrap" class="ft95">insurance over $50,000 (former employees only). See</p>
               <p style="position:absolute;top:306px;left:339px;white-space:nowrap" class="ft91"><b>&#160;</b>the Form<b>&#160;</b>1040&#160;</p>
               <p style="position:absolute;top:319px;left:54px;white-space:nowrap" class="ft96">instructions.<br/><b>P—</b>Excludable moving expense reimbursements paid<b>&#160;</b>directly to a&#160;</p>
               <p style="position:absolute;top:350px;left:54px;white-space:nowrap" class="ft96">member of the U.S. Armed Forces (not included in box 1, 3, or 5)<br/><b>Q—</b>Nontaxable combat pay. See the Form 1040 instructions for details&#160;</p>
               <p style="position:absolute;top:380px;left:54px;white-space:nowrap" class="ft96">on reporting this amount.<br/><b>R—</b>Employer contributions to your Archer MSA. Report on<b>&#160;</b>Form 8853.<br/><b>S—</b>Employee salary reduction contributions under a section<b>&#160;</b>408(p)&#160;</p>
               <p style="position:absolute;top:429px;left:54px;white-space:nowrap" class="ft96">SIMPLE plan<br/><b>T—</b>Adoption benefits (not included in box 1). Complete Form 8839 to<b>&#160;</b></p>
               <p style="position:absolute;top:460px;left:54px;white-space:nowrap" class="ft96">figure any taxable and nontaxable amounts.<br/><b>V—</b>Income from exercise of nonstatutory stock option(s)<b>&#160;</b>(included in&#160;</p>
               <p style="position:absolute;top:490px;left:54px;white-space:nowrap" class="ft95">boxes 1, 3 (up to the social security wage base),</p>
               <p style="position:absolute;top:490px;left:312px;white-space:nowrap" class="ft91"><b>&#160;</b>and 5). See Pub. 525&#160;</p>
               <p style="position:absolute;top:503px;left:54px;white-space:nowrap" class="ft96">for reporting requirements.<br/><b>W—</b>Employer contributions (including amounts the employee elected to&#160;</p>
               <p style="position:absolute;top:534px;left:54px;white-space:nowrap" class="ft95">contribute using a section 125 (cafeteria) plan) to your health savings&#160;</p>
               <p style="position:absolute;top:547px;left:54px;white-space:nowrap" class="ft95">account.</p>
               <p style="position:absolute;top:547px;left:101px;white-space:nowrap" class="ft91"><b>&#160;</b>Report on Form 8889.</p>
               <p style="position:absolute;top:51px;left:475px;white-space:nowrap" class="ft91"><b>Y—</b>Deferrals under a section 409A nonqualified deferred compensation&#160;</p>
               <p style="position:absolute;top:64px;left:475px;white-space:nowrap" class="ft96">plan<br/><b>Z—</b>Income under a nonqualified deferred compensation plan that fails&#160;</p>
               <p style="position:absolute;top:95px;left:475px;white-space:nowrap" class="ft95">to satisfy section 409A. This amount is also included in box 1. It</p>
               <p style="position:absolute;top:95px;left:816px;white-space:nowrap" class="ft91"><b>&#160;</b>is&#160;</p>
               <p style="position:absolute;top:108px;left:475px;white-space:nowrap" class="ft95">subject to an additional 20% tax plus interest. See the Form 1040&#160;</p>
               <p style="position:absolute;top:121px;left:475px;white-space:nowrap" class="ft96">instructions.<br/><b>AA—</b>Designated Roth contributions under a section 401(k)<b>&#160;</b>plan<br/><b>BB—</b>Designated Roth contributions under a section 403(b)<b>&#160;</b>plan<br/><b>DD—</b>Cost of employer-sponsored health coverage.&#160;<b>The amount&#160;</b></p>
               <p style="position:absolute;top:187px;left:475px;white-space:nowrap" class="ft97"><b>reported with code DD is not taxable.<br/>EE—</b>Designated Roth contributions under a governmental section&#160;</p>
               <p style="position:absolute;top:218px;left:475px;white-space:nowrap" class="ft95">457(b) plan. This amount does not apply to contributions under a tax-</p>
               <p style="position:absolute;top:231px;left:475px;white-space:nowrap" class="ft96">exempt organization section 457(b) plan.<br/><b>FF—</b>Permitted benefits under a qualified small employer health&#160;</p>
               <p style="position:absolute;top:262px;left:475px;white-space:nowrap" class="ft96">reimbursement arrangement<br/><b>GG—</b>Income from qualified equity grants under section 83(i)<br/><b>HH—</b>Aggregate deferrals under section 83(i) elections as of the close of&#160;</p>
               <p style="position:absolute;top:310px;left:475px;white-space:nowrap" class="ft96">the calendar year<br/><b>II—</b>Medicaid waiver payments excluded from gross income under&#160;</p>
               <p style="position:absolute;top:341px;left:475px;white-space:nowrap" class="ft96">Notice 2014-7.<br/><b>Box 13.&#160;</b>If the “Retirement plan” box is checked, special<b>&#160;</b>limits may&#160;</p>
               <p style="position:absolute;top:372px;left:475px;white-space:nowrap" class="ft95">apply to the amount of traditional IRA</p>
               <p style="position:absolute;top:372px;left:675px;white-space:nowrap" class="ft91"><b>&#160;</b>contributions you may deduct.&#160;</p>
               <p style="position:absolute;top:385px;left:475px;white-space:nowrap" class="ft96">See Pub. 590-A.<br/><b>Box 14.&#160;</b>Employers may use this box to report information such as state&#160;</p>
               <p style="position:absolute;top:416px;left:475px;white-space:nowrap" class="ft95">disability insurance taxes withheld, union dues, uniform payments,&#160;</p>
               <p style="position:absolute;top:429px;left:475px;white-space:nowrap" class="ft95">health insurance premiums deducted, nontaxable income, educational&#160;</p>
               <p style="position:absolute;top:442px;left:475px;white-space:nowrap" class="ft95">assistance payments, or a member of the clergy’s parsonage allowance&#160;</p>
               <p style="position:absolute;top:455px;left:475px;white-space:nowrap" class="ft95">and utilities. Railroad employers use this box to report railroad&#160;</p>
               <p style="position:absolute;top:468px;left:475px;white-space:nowrap" class="ft95">retirement (RRTA) compensation, Tier 1 tax, Tier 2 tax, Medicare tax,&#160;</p>
               <p style="position:absolute;top:481px;left:475px;white-space:nowrap" class="ft95">and Additional Medicare Tax. Include tips reported by the employee to&#160;</p>
               <p style="position:absolute;top:495px;left:475px;white-space:nowrap" class="ft96">the employer in railroad retirement (RRTA) compensation.<br/><b>Note:&#160;</b>Keep&#160;<b>Copy C&#160;</b>of Form W-2 for at least 3 years after<b>&#160;</b>the due date&#160;</p>
               <p style="position:absolute;top:525px;left:475px;white-space:nowrap" class="ft95">for filing your income tax return. However, to</p>
               <p style="position:absolute;top:525px;left:714px;white-space:nowrap" class="ft91"><b>&#160;</b>help&#160;<b>protect your social&#160;</b></p>
               <p style="position:absolute;top:538px;left:475px;white-space:nowrap" class="ft91"><b>security benefits</b>, keep Copy C<b>&#160;</b>until you begin receiving social security&#160;</p>
               <p style="position:absolute;top:552px;left:475px;white-space:nowrap" class="ft95">benefits, just in case</p>
               <p style="position:absolute;top:551px;left:585px;white-space:nowrap" class="ft91"><b>&#160;</b>there is a question about your work record and/or&#160;</p>
               <p style="position:absolute;top:565px;left:475px;white-space:nowrap" class="ft95">earnings</p>
               <p style="position:absolute;top:564px;left:521px;white-space:nowrap" class="ft91"><b>&#160;</b>in a particular year.&#160;</p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft100{font-size:10px;font-family:Times;color:#000000;}
                  .ft101{font-size:8px;font-family:Times;color:#000000;}
                  .ft102{font-size:8px;font-family:Times;color:#000000;}
                  .ft103{font-size:4px;font-family:Times;color:#000000;}
                  .ft104{font-size:5px;font-family:Times;color:#000000;}
                  .ft105{font-size:34px;font-family:Times;color:#000000;}
                  .ft106{font-size:14px;font-family:Times;color:#000000;}
                  .ft107{font-size:34px;font-family:Times;color:#000000;}
                  .ft108{font-size:10px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page10-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target010.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:36px;left:54px;white-space:nowrap" class="ft100">&#160; &#160; &#160;</p>
               <p style="position:absolute;top:66px;left:164px;white-space:nowrap" class="ft101">VOID</p>
               <p style="position:absolute;top:56px;left:236px;white-space:nowrap" class="ft102"><b>a &#160;</b>Employee’s social security number<br> <span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['social_security_number']; ?></span></p>
               <p style="position:absolute;top:72px;left:430px;white-space:nowrap" class="ft102"><b>&#160;</b>OMB No. 1545-0008&#160;</p>
               <p style="position:absolute;top:92px;left:63px;white-space:nowrap" class="ft102"><b>b &#160;</b>Employer identification number (EIN) <br> <span style="color: #000; font-size: 14px;"><?php echo htmlspecialchars($c_details[0]['Federal_Pin_Number'], ENT_QUOTES, 'UTF-8'); ?></span></p>
               <p style="position:absolute;top:128px;left:63px;white-space:nowrap" class="ft102"><b>c &#160;</b>Employer’s name, address, and ZIP code <br><span style="color: #000; font-size: 14px;"><?php echo $getlocation[0]['address']; ?></span></p>
               <p style="position:absolute;top:236px;left:63px;white-space:nowrap" class="ft102"><b>d &#160;</b>Control number</p>
               <p style="position:absolute;top:272px;left:63px;white-space:nowrap" class="ft102"><b>e &#160;</b>Employee’s first name and initial<br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['first_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:265px;white-space:nowrap" class="ft101">Last name<br><span style="color: #000; font-size: 14px;"><?php echo $gettaxdata[0]['last_name']; ?></span></p>
               <p style="position:absolute;top:272px;left:470px;white-space:nowrap" class="ft101">Suff.</p>
               <p style="position:absolute;top:416px;left:63px;white-space:nowrap" class="ft102"><b>f &#160;</b>Employee’s address and ZIP code <br><span style="color: #000; font-size: 14px; position: absolute; bottom: 18px;"><?php echo $e_details[0]['address_line_1']; ?> </span></p>
               <p style="position:absolute;top:92px;left:508px;white-space:nowrap" class="ft102"><b>1 &#160;&#160;</b>Wages, tips, other compensation
                  <br><span style="color: #000; font-size: 14px;"> 
                  $<?php echo htmlspecialchars($t_tax, ENT_QUOTES, 'UTF-8'); ?> 
                  </span>
               </p>
               <p style="position:absolute;top:92px;left:692px;white-space:nowrap" class="ft102"><b>2 &#160;&#160;</b>Federal income tax withheld<br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($overalltotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:128px;left:508px;white-space:nowrap" class="ft102"><b>3 &#160;&#160;</b>Social security wages <br><span style="color: #000; font-size: 14px;"><?php 
                  $S_tax = 0; 
                  $S_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$' .$S_tax;
                  ?></span></p>
               <p style="position:absolute;top:128px;left:692px;white-space:nowrap" class="ft102"><b>4 &#160;&#160;</b>Social security tax withheld <br>
                  <span style="color: #000; font-size: 14px;">
                  $<?php echo htmlspecialchars($stotal_amount, ENT_QUOTES, 'UTF-8'); ?>
                  </span>
               </p>
               <p style="position:absolute;top:164px;left:508px;white-space:nowrap" class="ft102"><b>5 &#160;&#160;</b>Medicare wages and tips <br><span style="color: #000; font-size: 14px;"><?php 
                  $t_tax = 0; 
                  $t_tax = $get_payslip_info[0]['overalltotal_amount'];
                  echo '$'. $t_tax;
                  ?></span></p>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft102"><b>6 &#160;&#160;</b>Medicare tax withheld<br>
               <p style="position:absolute;top:164px;left:692px;white-space:nowrap" class="ft61"><b>6 &#160;&#160;</b>Medicare tax withheld <br>
                  <span style="color: black;font-size: large;font-size: 14px;">$<?php echo htmlspecialchars($mtotal_amount, ENT_QUOTES, 'UTF-8'); ?>
               </p>
               <p style="position:absolute;top:200px;left:508px;white-space:nowrap" class="ft102"><b>7 &#160;&#160;</b>Social security tips</p>
               <p style="position:absolute;top:200px;left:692px;white-space:nowrap" class="ft102"><b>8 &#160;&#160;</b>Allocated tips</p>
               <p style="position:absolute;top:236px;left:508px;white-space:nowrap" class="ft102"><b>9 &#160;&#160;</b></p>
               <p style="position:absolute;top:236px;left:686px;white-space:nowrap" class="ft102"><b>10 &#160;&#160;</b>Dependent care benefits</p>
               <p style="position:absolute;top:272px;left:503px;white-space:nowrap" class="ft102"><b>11 &#160;&#160;</b>Nonqualified plans</p>
               <p style="position:absolute;top:272px;left:686px;white-space:nowrap" class="ft102"><b>12a&#160;</b>See instructions for box 12</p>
               <p style="position:absolute;top:282px;left:687px;white-space:nowrap" class="ft103">C</p>
               <p style="position:absolute;top:287px;left:687px;white-space:nowrap" class="ft103">o&#160;</p>
               <p style="position:absolute;top:293px;left:687px;white-space:nowrap" class="ft103">d&#160;</p>
               <p style="position:absolute;top:298px;left:688px;white-space:nowrap" class="ft103">e</p>
               <p style="position:absolute;top:308px;left:686px;white-space:nowrap" class="ft102"><b>12b</b></p>
               <p style="position:absolute;top:318px;left:687px;white-space:nowrap" class="ft103">C</p>
               <p style="position:absolute;top:323px;left:687px;white-space:nowrap" class="ft103">o&#160;</p>
               <p style="position:absolute;top:329px;left:687px;white-space:nowrap" class="ft103">d&#160;</p>
               <p style="position:absolute;top:334px;left:688px;white-space:nowrap" class="ft103">e</p>
               <p style="position:absolute;top:344px;left:686px;white-space:nowrap" class="ft102"><b>12c</b></p>
               <p style="position:absolute;top:354px;left:687px;white-space:nowrap" class="ft103">C</p>
               <p style="position:absolute;top:359px;left:687px;white-space:nowrap" class="ft103">o&#160;</p>
               <p style="position:absolute;top:365px;left:687px;white-space:nowrap" class="ft103">d&#160;</p>
               <p style="position:absolute;top:370px;left:688px;white-space:nowrap" class="ft103">e</p>
               <p style="position:absolute;top:380px;left:686px;white-space:nowrap" class="ft102"><b>12d</b></p>
               <p style="position:absolute;top:390px;left:687px;white-space:nowrap" class="ft103">C</p>
               <p style="position:absolute;top:395px;left:687px;white-space:nowrap" class="ft103">o&#160;</p>
               <p style="position:absolute;top:401px;left:687px;white-space:nowrap" class="ft103">d&#160;</p>
               <p style="position:absolute;top:406px;left:688px;white-space:nowrap" class="ft103">e</p>
               <p style="position:absolute;top:308px;left:503px;white-space:nowrap" class="ft102"><b>13</b></p>
               <p style="position:absolute;top:307px;left:523px;white-space:nowrap" class="ft104">Statutory&#160;</p>
               <p style="position:absolute;top:315px;left:523px;white-space:nowrap" class="ft104">employee</p>
               <p style="position:absolute;top:307px;left:577px;white-space:nowrap" class="ft104">Retirement&#160;</p>
               <p style="position:absolute;top:315px;left:577px;white-space:nowrap" class="ft104">plan</p>
               <p style="position:absolute;top:307px;left:631px;white-space:nowrap" class="ft104">Third-party&#160;</p>
               <p style="position:absolute;top:315px;left:631px;white-space:nowrap" class="ft104">sick pay</p>
               
               <p style="position:absolute;top:344px;left:503px;white-space:nowrap ;" class="ft32"><b>14 &#160;</b>Other
                <br>
                
                <?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';
                }
                 ?>




               </p>
               <?php
                  $matchedCode = '';
                  $matchedTaxType = '';
                  
                  $matchedCode1 = '';
                  $matchedTaxType1 = '';
                  
                  $matchedCode2 = '';
                  $matchedTaxType2 = '';
                  
                  
                  $matchedCode3 = '';
                  $matchedTaxType3 = '';
                  
                  foreach ($StatetaxType as $data) {
                      if ($data['tax_type'] === 'state_tax') {
                          $matchedCode = $data['code'];
                          $matchedTaxType = $data['tax_type'];
                          break;
                      }
                  }
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                      if ($datas['tax_type'] === 'living_state_tax') {
                          $matchedCode1 = $datas['code'];
                          $matchedTaxType1 = $datas['tax_type'];
                          break;
                      }
                  }
                  
                  
                   
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'living_local_tax') {
                      $matchedCode2 = $datas['code'];
                      $matchedTaxType2 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                  
                  
                  foreach ($StatetaxType as $datas) {
                  
                    if ($datas['tax_type'] === 'local_tax') {
                      $matchedCode3 = $datas['code'];
                      $matchedTaxType3 = $datas['tax_type'];
                      break;
                    }
                  }
                  
                    
                  ?>
               <p style="position:absolute;top:434px;left:57px;white-space:nowrap" class="ft102"><b>15 &#160;</b>State&#160;Employer’s state ID number 
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative;">
                  <?php echo htmlspecialchars($matchedCode, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px;"><?php echo !empty($matchedCode) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
                  <br>  
                  <span style="color: #000; font-size: 14px; position: relative; top: 15px;">
                  <?php echo htmlspecialchars($matchedCode1, ENT_QUOTES, 'UTF-8'); ?>  
                  </span> 
                  <span style="color: #000; font-size: 14px; position: relative; left: 60px; top: 15px;"><?php echo !empty($matchedCode1) ? htmlspecialchars($c_details[0]['State_Tax_ID_Number'], ENT_QUOTES, 'UTF-8') : ''; ?></span>
               </p>
               </p>
               <p style="position:absolute;top:434px;left:296px;white-space:nowrap" class="ft102"><b>16 &#160;</b>State wages, tips, etc 
                  <br><span style="color: #000; font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>  
               </p>
               <?php  if($gettaxdata[0]['payroll_type'] == 'Hourly') {
                
                $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';

                }else if ($gettaxdata[0]['payroll_type'] == 'Salaried-weekly' ) {
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax1']) ? number_format($stateTax[0]['overalltotal_statetax1'], 2) : '0';

                } else if($gettaxdata[0]['payroll_type'] == 'Salaried-BiWeekly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax2']) ? number_format($stateTax[0]['overalltotal_statetax2'], 2) : '0';

                }else if($gettaxdata[0]['payroll_type'] == 'Salaried-Monthly' ){
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax3']) ? number_format($stateTax[0]['overalltotal_statetax3'], 2) : '0';

                }
                else{
                  $overalltotal_statetax = isset($stateTax[0]['overalltotal_statetax0']) ? number_format($stateTax[0]['overalltotal_statetax0'], 2) : '0';
                }
                 ?>



               <?php
                  $overalltotal_statetaxworking = isset($stateworkingtax[0]['overalltotal_statetaxworking']) ? number_format($stateworkingtax[0]['overalltotal_statetaxworking'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:427px;white-space:nowrap" class="ft102"><b>17 &#160;</b>State income tax 
                  <br> <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                   <?php echo !empty($matchedCode) ? htmlspecialchars($currency . $overalltotal_statetax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode1) ? htmlspecialchars($currency . $overalltotal_statetaxworking, ENT_QUOTES, 'UTF-8') : ''; ?>    
                  </span> 
               </p>
               <p style="position:absolute;top:434px;left:545px;white-space:nowrap" class="ft102"><b>18 &#160;</b>Local wages, tips, etc
                  <br>
                  <span style="color: #000; font-size: 14px;position: relative;left: 37px;">
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $t_tax, ENT_QUOTES, 'UTF-8') : ''; ?> 
                  </span> 
               </p>
               <?php
                  $overalltotal_localtax = isset($localTax[0]['overalltotal_localtax']) ? number_format($localTax[0]['overalltotal_localtax'], 2) : '0';
                  ?>
               <?php
                  $livinglocaltax = isset($livinglocaldata[0]['livinglocaltax']) ? number_format($livinglocaldata[0]['livinglocaltax'], 2) : '0';
                  ?>
               <p style="position:absolute;top:434px;left:674px;white-space:nowrap" class="ft102"><b>19 &#160;</b>Local income tax<br> 
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo !empty($matchedCode3) ? htmlspecialchars($currency . $overalltotal_localtax, ENT_QUOTES, 'UTF-8') : ''; ?>  
                  </span>
                  <span style="color: #000; font-size: 14px; position: relative; top: 30px;">
                  <?php echo !empty($matchedCode2) ? htmlspecialchars($currency . $livinglocaltax, ENT_QUOTES, 'UTF-8') : ''; ?>
                  </span>  
               </p>
               <p style="position:absolute;top:434px;left:793px;white-space:nowrap" class="ft102"><b>20 &#160;</b>Locality name
               	<br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;left: 37px;"> 
                  <?php echo htmlspecialchars($matchedCode3, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
                  <br>
                  <span style="color: black;font-size: large;font-size: 14px;position: relative;top: 9px;left: 37px; "> 
                  <?php echo htmlspecialchars($matchedCode2, ENT_QUOTES, 'UTF-8'); ?>  
                  </span>
               </p>
               <p style="position:absolute;top:528px;left:54px;white-space:nowrap" class="ft102"><b>Form</b></p>
               <p style="position:absolute;top:504px;left:86px;white-space:nowrap" class="ft105"><b>W-2</b></p>
               <p style="position:absolute;top:516px;left:160px;white-space:nowrap" class="ft106">Wage and Tax Statement</p>
               <p style="position:absolute;top:509px;left:434px;white-space:nowrap" class="ft107">2024</p>
               <p style="position:absolute;top:513px;left:608px;white-space:nowrap" class="ft101">Department of the Treasury—Internal Revenue Service&#160;</p>
               <p style="position:absolute;top:532px;left:654px;white-space:nowrap" class="ft102"><b>For Privacy Act and Paperwork Reduction&#160;</b></p>
               <p style="position:absolute;top:544px;left:676px;white-space:nowrap" class="ft102"><b>Act Notice, see separate instructions.</b></p>
               <p style="position:absolute;top:544px;left:54px;white-space:nowrap" class="ft108"><b>Copy D—For Employer</b></p>
            </div>
         </body>
      </html>
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
         <head>
            <title></title>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
            <br/>
            <style type="text/css">
               <!--
                  p {margin: 0; padding: 0;}	.ft110{font-size:19px;font-family:Times;color:#000000;}
                  .ft111{font-size:11px;font-family:Times;color:#000000;}
                  .ft112{font-size:11px;font-family:Times;color:#000000;}
                  .ft113{font-size:11px;font-family:Times;color:#000000;}
                  .ft114{font-size:11px;line-height:20px;font-family:Times;color:#000000;}
                  -->
            </style>
         </head>
         <body bgcolor="#A0A0A0" vlink="blue" link="blue">
            <div id="page11-div" style="position:relative;width:918px;height:1188px;     margin-left: 300px;">
               <img width="918" height="1188" src="<?php echo base_url('assets/payrollform/w2 form new/target011.png'); ?>" alt="background image"/>
               <p style="position:absolute;top:49px;left:54px;white-space:nowrap" class="ft110"><b>Employers, Please Note—</b></p>
               <p style="position:absolute;top:79px;left:54px;white-space:nowrap" class="ft111">Specific information needed to complete Form W-2 is available&#160;</p>
               <p style="position:absolute;top:94px;left:54px;white-space:nowrap" class="ft111">in a separate booklet titled the 2024 General Instructions for&#160;</p>
               <p style="position:absolute;top:109px;left:54px;white-space:nowrap" class="ft111">Forms W-2 and W-3. You can order these instructions and&#160;</p>
               <p style="position:absolute;top:123px;left:54px;white-space:nowrap" class="ft114">additional forms at&#160;<i>www.irs.gov/OrderForms</i>.<br/><b>Caution:&#160;</b>Do not send the SSA any Forms W-2 and W-3 that you&#160;</p>
               <p style="position:absolute;top:158px;left:54px;white-space:nowrap" class="ft111">have printed from IRS.gov. The SSA is unable to process these&#160;</p>
               <p style="position:absolute;top:173px;left:54px;white-space:nowrap" class="ft111">forms. Instead, you can create and submit them online. See&#160;</p>
               <p style="position:absolute;top:188px;left:54px;white-space:nowrap" class="ft114"><i>E-filing</i>, later.<br/><b>Due dates.&#160;</b>By January 31, 2025, furnish Copies B, C, and 2 to&#160;</p>
               <p style="position:absolute;top:223px;left:54px;white-space:nowrap" class="ft111">each person who was your employee during 2024. Mail or&#160;</p>
               <p style="position:absolute;top:238px;left:54px;white-space:nowrap" class="ft111">electronically file Copy A of Form(s) W-2 and W-3 with the SSA&#160;</p>
               <p style="position:absolute;top:252px;left:54px;white-space:nowrap" class="ft114">by January 31, 2025. See the separate instructions.<br/><b>Need help?</b>&#160;If you have questions about reporting on Form W-2,&#160;</p>
               <p style="position:absolute;top:287px;left:54px;white-space:nowrap" class="ft111">call the Technical Services Operation (TSO) toll free at&#160;</p>
               <p style="position:absolute;top:302px;left:54px;white-space:nowrap" class="ft111">866-455-7438 or 304-263-8700 (not toll free). Deaf or hard-of-</p>
               <p style="position:absolute;top:51px;left:475px;white-space:nowrap" class="ft111">hearing customers may call any of our toll-free numbers using&#160;</p>
               <p style="position:absolute;top:65px;left:475px;white-space:nowrap" class="ft114">their choice of relay service.<br/><b>E-filing.</b>&#160;If you file 10 or more information returns, you must file&#160;</p>
               <p style="position:absolute;top:101px;left:475px;white-space:nowrap" class="ft111">electronically. See Regulations section 301.6011-2 for more&#160;</p>
               <p style="position:absolute;top:115px;left:475px;white-space:nowrap" class="ft111">information. Even if you aren’t required to file electronically,&#160;</p>
               <p style="position:absolute;top:130px;left:475px;white-space:nowrap" class="ft111">doing so can save you time and effort. Employers may use the&#160;</p>
               <p style="position:absolute;top:144px;left:475px;white-space:nowrap" class="ft111">SSA’s W-2 Online service to create, save, print, and&#160;</p>
               <p style="position:absolute;top:159px;left:475px;white-space:nowrap" class="ft111">electronically submit up to 50 Form(s) W-2 at a time. When you&#160;</p>
               <p style="position:absolute;top:174px;left:475px;white-space:nowrap" class="ft112"><i>e-file</i>&#160;with the SSA, no separate Form W-3 filing is required. An&#160;</p>
               <p style="position:absolute;top:188px;left:475px;white-space:nowrap" class="ft111">electronic Form W-3 will be created for you by the W-2 Online&#160;</p>
               <p style="position:absolute;top:203px;left:475px;white-space:nowrap" class="ft111">service. For information, visit the SSA’s Employer W-2 Filing&#160;</p>
               <p style="position:absolute;top:218px;left:475px;white-space:nowrap" class="ft114">Instructions &amp; Information website at&#160;<i>www.SSA.gov/employer</i>.&#160;<br/><b>Future developments.</b>&#160;For the latest information about&#160;</p>
               <p style="position:absolute;top:253px;left:475px;white-space:nowrap" class="ft111">developments affecting Form W-2 and its instructions, such as&#160;</p>
               <p style="position:absolute;top:267px;left:475px;white-space:nowrap" class="ft111">legislation enacted after we release them, go to&#160;</p>
               <p style="position:absolute;top:282px;left:475px;white-space:nowrap" class="ft112"><i>www.irs.gov/FormW2</i>.&#160;</p>
            </div>
         </body>
      </html>
   </section>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
<script>
   async function downloadPagesAsPDF() {
       const ids = ['page1-div', 'page2-div', 'page3-div', 'page4-div', 'page5-div', 'page6-div', 'page7-div', 'page8-div', 'page9-div', 'page10-div', 'page11-div'];
       const elements = ids.map(id => document.getElementById(id)).filter(el => el !== null);
   
       if (elements.length === 0) {
           alert('No elements found');
           return;
       }
   
       // Convert pixel dimensions to mm for PDF
       const pixelToMmRatio = 25.4 / 96; // 96 DPI
       const widthInMm = 918 * pixelToMmRatio;
       const heightInMm = 1188 * pixelToMmRatio;
   
       const pdf = new jspdf.jsPDF({
           orientation: 'p',
           unit: 'mm',
           format: [widthInMm, heightInMm]
       });
   
       for (let i = 0; i < elements.length; i++) {
           const element = elements[i];
           const canvas = await html2canvas(element, { scale: 1 });
           const imgData = canvas.toDataURL('image/jpeg', 1.0);
   
           let imgX = 0;
           let imgY = 0;
   
           if (i !== 0) {
               pdf.addPage([widthInMm, heightInMm], 'p');
           }
   
           pdf.addImage(imgData, 'JPEG', imgX, imgY, widthInMm, heightInMm);
       }
   
       pdf.save('W2Form.pdf');
   }
</script>